# Mission Operations Copilot

A demo-ready spacecraft-health decision-support application. It streams simulated telemetry, identifies unusual patterns, retrieves related operator procedures and incident records, and records investigations. It is not connected to a spacecraft and has no command interface.

## Safety and data provenance

- The ORBIT-X1 spacecraft and its live-looking telemetry stream are simulated.
- Seeded incident reports and procedures are fictional demonstration records, not public mission history.
- Uploaded telemetry keeps an explicit `OPERATOR UPLOAD` or `PUBLIC HISTORICAL DATA` source label.
- The interface separates observed facts, event correlations, hypotheses, and recommendations. It reports missing evidence and abstains when support is insufficient.
- The anomaly replay is a deterministic demonstration. Its timing and data are not operational telemetry.
- Every investigation is written to the audit log with cited source identifiers and `commandIssued: NONE`.
- No live telemetry uplink, command encoder, or spacecraft-control route exists.

## Features

- Responsive mission dashboard with current state, recent events, and telemetry trends.
- Simulated telemetry stream over WebSocket, with pause/start controls and an incident replay.
- Isolation Forest anomaly scoring over telemetry plus derived trend features.
- CSV/JSON telemetry uploads and mission-event ingestion.
- Hybrid evidence retrieval over procedure chunks, telemetry, events, and incident summaries.
- Incident views with correlated timelines and similar-incident search.
- Evidence-grounded investigation responses, confidence, evidence sufficiency, source citations, and missing-evidence lists.
- Persistent investigation audit log and a stored contact form.

## Architecture

- **Frontend:** React, Vite, TanStack Query, generated OpenAPI hooks, and Wouter routing in `artifacts/mission-ops`.
- **API:** Express service in `artifacts/api-server`, with REST endpoints and a native WebSocket endpoint at `/api/ws/telemetry`.
- **Database:** PostgreSQL with Drizzle schemas in `lib/db`.
- **API contract:** `lib/api-spec/openapi.yaml`; generated client and Zod schemas are kept in sync with code generation.
- **Local reasoning:** Deterministic, evidence-grounded rules for this offline demo; no external AI service or credentials are required.
- **Retrieval:** BM25 plus deterministic signed-token vectors and term-overlap reranking. This workspace's PostgreSQL instance does not have the `vector` extension installed, so vectors are stored as JSONB and compared in the API process rather than with pgvector. Token vectors are a lightweight retrieval aid, not sentence-transformer embeddings.

## Run in Replit

The workspace already defines managed services for the API and web app:

- `artifacts/api-server: API Server`
- `artifacts/mission-ops: web`

Start both managed services. The API initializes the database seed and simulation on startup; the web service uses the generated API client.

If schema changes are made, apply them with:

```bash
pnpm --filter @workspace/db run push
```

Validate the workspace with:

```bash
pnpm run typecheck
```

## Main API routes

- `GET /api/dashboard`, `/api/spacecraft`
- `GET /api/telemetry/latest`, `/api/telemetry/history`
- `POST /api/telemetry/ingest`, `GET /api/events`, `POST /api/events/ingest`
- `GET /api/incidents`, `GET /api/incidents/{incident_id}`
- `POST /api/investigate`, `POST /api/incidents/{incident_id}/investigate`
- `POST /api/rag/search`, `GET /api/evidence/{source_id}`
- `GET /api/audit`, `GET /api/similar-incidents/{incident_id}`
- `GET /api/simulation/status`, `POST /api/simulation/start`, `/stop`, `/replay-incident`
- `WS /api/ws/telemetry`
- `POST /api/contact`
