import app from "./app";
import { logger } from "./lib/logger";
import { seedDatabase } from "./lib/seed";
import {
  attachTelemetryWebSocket,
  initializeSimulation,
} from "./lib/simulation";

const rawPort = process.env["PORT"];

if (!rawPort) {
  throw new Error(
    "PORT environment variable is required but was not provided.",
  );
}

const port = Number(rawPort);

if (Number.isNaN(port) || port <= 0) {
  throw new Error(`Invalid PORT value: "${rawPort}"`);
}

async function startServer(): Promise<void> {
  await seedDatabase();
  initializeSimulation();
  const server = app.listen(port, () => {
    logger.info({ port }, "Server listening");
  });
  attachTelemetryWebSocket(server);
}

void startServer().catch((error: unknown) => {
  logger.error({ error }, "API server initialization failed");
  process.exit(1);
});
