const VECTOR_SIZE = 192;
const STOP_WORDS = new Set([
  "a",
  "an",
  "and",
  "are",
  "as",
  "at",
  "be",
  "by",
  "did",
  "do",
  "for",
  "from",
  "how",
  "i",
  "in",
  "is",
  "it",
  "of",
  "on",
  "or",
  "the",
  "this",
  "to",
  "was",
  "what",
  "when",
  "why",
  "with",
]);

export function tokenize(value: string): string[] {
  return value
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, " ")
    .trim()
    .split(/\s+/)
    .filter((token) => token.length > 1 && !STOP_WORDS.has(token));
}

function hashToken(token: string): number {
  let hash = 2166136261;
  for (const character of token) {
    hash ^= character.charCodeAt(0);
    hash = Math.imul(hash, 16777619);
  }
  return hash >>> 0;
}

export function embedText(value: string): number[] {
  const vector = new Array<number>(VECTOR_SIZE).fill(0);
  for (const token of tokenize(value)) {
    const hash = hashToken(token);
    const index = hash % VECTOR_SIZE;
    vector[index] += hash & 1 ? 1 : -1;
  }
  const length = Math.sqrt(vector.reduce((sum, component) => sum + component ** 2, 0));
  return length > 0 ? vector.map((component) => component / length) : vector;
}

export function cosineSimilarity(left: number[], right: number[]): number {
  const size = Math.min(left.length, right.length);
  let dot = 0;
  let leftNorm = 0;
  let rightNorm = 0;
  for (let i = 0; i < size; i += 1) {
    const a = left[i] ?? 0;
    const b = right[i] ?? 0;
    dot += a * b;
    leftNorm += a * a;
    rightNorm += b * b;
  }
  if (leftNorm === 0 || rightNorm === 0) return 0;
  return dot / Math.sqrt(leftNorm * rightNorm);
}

export function bm25Score(query: string, documents: string[]): number[] {
  const queryTokens = tokenize(query);
  const tokenized = documents.map(tokenize);
  const averageLength =
    tokenized.reduce((sum, tokens) => sum + tokens.length, 0) /
      Math.max(1, tokenized.length) || 1;
  const documentFrequency = new Map<string, number>();
  for (const tokens of tokenized) {
    for (const token of new Set(tokens)) {
      documentFrequency.set(token, (documentFrequency.get(token) ?? 0) + 1);
    }
  }

  return tokenized.map((tokens) => {
    let score = 0;
    for (const term of queryTokens) {
      const frequency = tokens.filter((token) => token === term).length;
      if (frequency === 0) continue;
      const df = documentFrequency.get(term) ?? 0;
      const idf = Math.log(1 + (documents.length - df + 0.5) / (df + 0.5));
      const k1 = 1.5;
      const b = 0.75;
      score +=
        idf *
        ((frequency * (k1 + 1)) /
          (frequency +
            k1 * (1 - b + b * (tokens.length / averageLength))));
    }
    return score;
  });
}

export function hybridScores(
  query: string,
  documents: Array<{ content: string; embedding?: number[] }>,
): number[] {
  const lexical = bm25Score(
    query,
    documents.map((document) => document.content),
  );
  const maxLexical = Math.max(1, ...lexical);
  const queryEmbedding = embedText(query);
  const queryTerms = new Set(tokenize(query));

  return documents.map((document, index) => {
    const semantic = Math.max(
      0,
      cosineSimilarity(queryEmbedding, document.embedding ?? embedText(document.content)),
    );
    const lexicalScore = (lexical[index] ?? 0) / maxLexical;
    const candidateTerms = new Set(tokenize(document.content));
    const overlap =
      [...queryTerms].filter((term) => candidateTerms.has(term)).length /
      Math.max(1, queryTerms.size);
    const rerank = overlap >= 0.5 ? 1 : 0.82;
    return (lexicalScore * 0.48 + semantic * 0.34 + overlap * 0.18) * rerank;
  });
}
