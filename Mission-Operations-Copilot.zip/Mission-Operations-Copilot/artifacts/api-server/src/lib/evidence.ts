import { desc, eq } from "drizzle-orm";
import {
  db,
  documentChunksTable,
  documentsTable,
  incidentsTable,
  missionEventsTable,
  telemetryTable,
} from "@workspace/db";
import { hybridScores } from "./evidence-search";
import { serializeEvent, serializeIncident, serializeTelemetry } from "./serializers";

export interface EvidenceItem {
  sourceId: string;
  sourceType: string;
  title: string;
  content: string;
  occurredAt: string | null;
  score: number;
  relevance: string;
}

interface Candidate extends EvidenceItem {
  embedding?: number[];
}

async function candidates(): Promise<Candidate[]> {
  const chunks = await db
    .select({
      id: documentChunksTable.id,
      content: documentChunksTable.content,
      embedding: documentChunksTable.embedding,
      documentId: documentsTable.id,
      title: documentsTable.title,
      sourceType: documentsTable.sourceType,
      occurredAt: documentsTable.occurredAt,
    })
    .from(documentChunksTable)
    .innerJoin(documentsTable, eq(documentChunksTable.documentId, documentsTable.id));

  const [telemetry, events, incidents] = await Promise.all([
    db.select().from(telemetryTable).orderBy(desc(telemetryTable.timestamp)).limit(120),
    db.select().from(missionEventsTable).orderBy(desc(missionEventsTable.occurredAt)).limit(80),
    db.select().from(incidentsTable).orderBy(desc(incidentsTable.openedAt)).limit(40),
  ]);

  const docCandidates = chunks.map((chunk) => ({
    sourceId: chunk.id,
    sourceType: chunk.sourceType,
    title: chunk.title,
    content: chunk.content,
    occurredAt: chunk.occurredAt?.toISOString() ?? null,
    score: 0,
    relevance: "Document chunk",
    embedding: chunk.embedding,
  }));
  const telemetryCandidates = telemetry.map((row) => {
    const record = serializeTelemetry(row);
    return {
      sourceId: row.id,
      sourceType: "TELEMETRY",
      title: `Telemetry sample · ${row.id}`,
      content:
        `${record.timestamp}: battery voltage ${row.batteryVoltage.toFixed(2)} V; ` +
        `solar power ${row.solarPower.toFixed(1)} W; battery temperature ` +
        `${row.batteryTemperature.toFixed(1)} °C; communication signal ` +
        `${row.communicationSignal.toFixed(1)} dBm; attitude error ` +
        `${row.attitudeError.toFixed(3)}°; anomaly score ` +
        `${row.anomalyScore.toFixed(2)} (${row.anomalyStatus}). ` +
        `Source: ${row.sourceLabel}.`,
      occurredAt: record.timestamp,
      score: 0,
      relevance: "Telemetry record",
    };
  });
  const eventCandidates = events.map((row) => {
    const event = serializeEvent(row);
    return {
      sourceId: row.id,
      sourceType: "EVENT",
      title: `${row.subsystem} · ${row.eventType}`,
      content: `${row.description} ${row.severity}. Source: ${row.sourceLabel}.`,
      occurredAt: event.occurredAt,
      score: 0,
      relevance: "Mission event",
    };
  });
  const incidentCandidates = incidents.map((row) => {
    const incident = serializeIncident(row);
    return {
      sourceId: row.id,
      sourceType: "HISTORICAL INCIDENT",
      title: row.title,
      content: `${row.summary} Status: ${row.status}. Severity: ${row.severity}.`,
      occurredAt: incident.openedAt,
      score: 0,
      relevance: "Historical incident",
    };
  });
  return [...docCandidates, ...telemetryCandidates, ...eventCandidates, ...incidentCandidates];
}

export async function searchEvidence(
  query: string,
  limit = 8,
): Promise<EvidenceItem[]> {
  const items = await candidates();
  const scores = hybridScores(
    query,
    items.map((item) => ({ content: `${item.title} ${item.content}`, embedding: item.embedding })),
  );
  return items
    .map((item, index) => ({
      ...item,
      score: Number(scores[index]?.toFixed(4) ?? "0"),
      relevance: "Hybrid BM25 + local semantic similarity, reranked by term overlap",
    }))
    .filter((item) => item.score > 0)
    .sort((left, right) => right.score - left.score)
    .slice(0, limit)
    .map(({ embedding: _embedding, ...item }) => item);
}

export async function getEvidenceById(sourceId: string): Promise<EvidenceItem | undefined> {
  const [telemetry] = await db
    .select()
    .from(telemetryTable)
    .where(eq(telemetryTable.id, sourceId))
    .limit(1);
  if (telemetry) {
    const row = serializeTelemetry(telemetry);
    return {
      sourceId: telemetry.id,
      sourceType: "TELEMETRY",
      title: `Telemetry sample · ${telemetry.id}`,
      content:
        `${row.timestamp}: battery voltage ${telemetry.batteryVoltage.toFixed(2)} V; ` +
        `solar power ${telemetry.solarPower.toFixed(1)} W; battery temperature ` +
        `${telemetry.batteryTemperature.toFixed(1)} °C; communication signal ` +
        `${telemetry.communicationSignal.toFixed(1)} dBm; attitude error ` +
        `${telemetry.attitudeError.toFixed(3)}°; anomaly score ` +
        `${telemetry.anomalyScore.toFixed(2)} (${telemetry.anomalyStatus}). ` +
        `Source: ${telemetry.sourceLabel}.`,
      occurredAt: row.timestamp,
      score: 1,
      relevance: "Direct source lookup",
    };
  }

  const [event] = await db
    .select()
    .from(missionEventsTable)
    .where(eq(missionEventsTable.id, sourceId))
    .limit(1);
  if (event) {
    return {
      sourceId: event.id,
      sourceType: "EVENT",
      title: `${event.subsystem} · ${event.eventType}`,
      content: `${event.description} ${event.severity}. Source: ${event.sourceLabel}.`,
      occurredAt: event.occurredAt.toISOString(),
      score: 1,
      relevance: "Direct source lookup",
    };
  }

  const [incident] = await db
    .select()
    .from(incidentsTable)
    .where(eq(incidentsTable.id, sourceId))
    .limit(1);
  if (incident) {
    const row = serializeIncident(incident);
    return {
      sourceId: incident.id,
      sourceType: "HISTORICAL INCIDENT",
      title: incident.title,
      content: `${incident.summary} Status: ${incident.status}. Severity: ${incident.severity}.`,
      occurredAt: row.openedAt,
      score: 1,
      relevance: "Direct source lookup",
    };
  }

  const [chunk] = await db
    .select({
      id: documentChunksTable.id,
      content: documentChunksTable.content,
      documentId: documentsTable.id,
      title: documentsTable.title,
      sourceType: documentsTable.sourceType,
      occurredAt: documentsTable.occurredAt,
    })
    .from(documentChunksTable)
    .innerJoin(documentsTable, eq(documentChunksTable.documentId, documentsTable.id))
    .where(eq(documentChunksTable.id, sourceId))
    .limit(1);
  if (chunk) {
    return {
      sourceId: chunk.id,
      sourceType: chunk.sourceType,
      title: chunk.title,
      content: chunk.content,
      occurredAt: chunk.occurredAt?.toISOString() ?? null,
      score: 1,
      relevance: "Direct source lookup",
    };
  }
  return undefined;
}

export async function getTelemetryEvidence(limit = 120): Promise<EvidenceItem[]> {
  return searchEvidence("telemetry battery solar power temperature communication attitude anomaly", limit);
}
