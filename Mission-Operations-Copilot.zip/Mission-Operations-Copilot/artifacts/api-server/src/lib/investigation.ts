import { randomUUID } from "node:crypto";
import { desc, eq } from "drizzle-orm";
import {
  auditLogsTable,
  db,
  incidentsTable,
  missionEventsTable,
  telemetryTable,
} from "@workspace/db";
import { getEvidenceById, searchEvidence } from "./evidence";
import { serializeEvent, serializeTelemetry } from "./serializers";

interface Claim {
  text: string;
  validation: "SUPPORTED" | "PARTIALLY SUPPORTED" | "UNSUPPORTED";
  sourceIds: string[];
}

function claim(
  text: string,
  validation: Claim["validation"],
  sourceIds: string[],
): Claim {
  return { text, validation, sourceIds: [...new Set(sourceIds)] };
}

export async function investigateQuestion(
  question: string,
  incidentId: string | null = null,
) {
  const [sources, telemetry, events] = await Promise.all([
    searchEvidence(question, 12),
    db.select().from(telemetryTable).orderBy(desc(telemetryTable.timestamp)).limit(120),
    db.select().from(missionEventsTable).orderBy(desc(missionEventsTable.occurredAt)).limit(60),
  ]);
  const lower = question.toLowerCase();
  const asksPhysicalDamage =
    /\b(break|broken|crack|cracked|physically|damage|damaged|fracture)\b/.test(lower);
  const asksBattery = /\b(battery|voltage|power|configuration)\b/.test(lower);
  const asksCommunication = /\b(communication|signal|link)\b/.test(lower);
  const knownEvidenceQuestion =
    asksBattery ||
    asksCommunication ||
    /\b(what happened|evidence|similar incident|investigate)\b/.test(lower);
  const procedureMatches = asksBattery
    ? await searchEvidence("P-017 low voltage investigation procedure battery", 3)
    : [];
  const retrievedSources = [
    ...new Map(
      [...sources, ...procedureMatches].map((source) => [source.sourceId, source]),
    ).values(),
  ];

  const sortedTelemetry = [...telemetry].sort(
    (left, right) => left.timestamp.getTime() - right.timestamp.getTime(),
  );
  const batteryLow = sortedTelemetry.filter((row) => row.batteryVoltage < 27.5);
  const recentLow = batteryLow.slice(-30);
  const lowRecord = recentLow.at(-1);
  let healthyRecord = undefined;
  if (lowRecord) {
    for (let index = sortedTelemetry.length - 1; index >= 0; index -= 1) {
      const row = sortedTelemetry[index];
      if (
        row &&
        row.timestamp.getTime() < lowRecord.timestamp.getTime() &&
        row.batteryVoltage >= 27.5
      ) {
        healthyRecord = row;
        break;
      }
    }
  }
  const voltageIds = [healthyRecord?.id, lowRecord?.id].filter(
    (id): id is string => Boolean(id),
  );
  const voltageDrop =
    healthyRecord && lowRecord
      ? healthyRecord.batteryVoltage - lowRecord.batteryVoltage
      : 0;

  const batteryEvent = events.find(
    (event) =>
      event.id === "EV-204" ||
      (event.subsystem === "POWER" &&
        (/CONFIGURATION_CHANGE/i.test(event.eventType) ||
          /configuration changed/i.test(event.description))),
  );
  const communicationEvent = events.find(
    (event) =>
      event.subsystem === "COMMUNICATION" &&
      event.severity !== "INFO",
  );
  const powerEvent = batteryEvent ? serializeEvent(batteryEvent) : undefined;
  const communicationEvidence = communicationEvent
    ? serializeEvent(communicationEvent)
    : undefined;
  const historical = sources.find((source) => source.sourceId === "INC-008");
  const procedure = retrievedSources.find(
    (source) => source.sourceId.startsWith("P-017"),
  );
  const telemetrySourceIds = sources
    .filter((source) => source.sourceType === "TELEMETRY")
    .slice(0, 3)
    .map((source) => source.sourceId);

  const observedFacts: Claim[] = [];
  if (healthyRecord && lowRecord && voltageDrop > 0.1) {
    observedFacts.push(
      claim(
        `Battery voltage changed from ${healthyRecord.batteryVoltage.toFixed(2)} V to ${lowRecord.batteryVoltage.toFixed(2)} V in the available telemetry samples.`,
        "SUPPORTED",
        voltageIds,
      ),
    );
  } else if (asksBattery && telemetry.length > 0) {
    const latest = telemetry[0]!;
    const latestSource = sources.find(
      (source) => source.sourceId === latest.id,
    );
    observedFacts.push(
      claim(
        `The latest recorded battery voltage is ${latest.batteryVoltage.toFixed(2)} V; recent records do not show a confirmed critical voltage decline.`,
        "SUPPORTED",
        [latest.id, ...(latestSource ? [latestSource.sourceId] : [])],
      ),
    );
  }
  if (asksCommunication && communicationEvidence) {
    observedFacts.push(
      claim(
        `A communication subsystem event was recorded as ${communicationEvent?.severity.toLowerCase()}.`,
        "SUPPORTED",
        [communicationEvidence.id],
      ),
    );
  }
  if (asksPhysicalDamage) {
    observedFacts.push(
      claim(
        "The available telemetry and event records do not directly inspect or image physical hardware.",
        "SUPPORTED",
        [
          ...telemetrySourceIds,
          ...(powerEvent ? [powerEvent.id] : []),
        ],
      ),
    );
  }

  const correlatedEvents: Claim[] = [];
  if (powerEvent && (asksBattery || incidentId === "INC-024")) {
    correlatedEvents.push(
      claim(
        "A power configuration event is present in the operational record; its timing is a correlation, not proof of cause.",
        "PARTIALLY SUPPORTED",
        [powerEvent.id, ...voltageIds],
      ),
    );
  }
  if (communicationEvidence && (asksCommunication || incidentId === "INC-024")) {
    correlatedEvents.push(
      claim(
        "A communication warning was also recorded; the available sequence alone does not establish a shared cause.",
        "PARTIALLY SUPPORTED",
        [communicationEvidence.id, ...telemetrySourceIds.slice(0, 1)],
      ),
    );
  }

  const historicalContext: Claim[] = historical
    ? [
        claim(
          "INC-008 documents a similar battery decline after a power configuration event; that historical sequence does not prove the cause of this event.",
          "SUPPORTED",
          [historical.sourceId],
        ),
      ]
    : [];

  const relevantCount =
    observedFacts.length + correlatedEvents.length + historicalContext.length;
  const sufficient = knownEvidenceQuestion && relevantCount > 0;
  const hypothesis = asksPhysicalDamage
    ? claim(
        "A physical solar-array break is not established by the available evidence.",
        "UNSUPPORTED",
        [...telemetrySourceIds, ...(powerEvent ? [powerEvent.id] : [])],
      )
    : asksBattery && powerEvent && voltageDrop > 0.1
      ? claim(
          "The configuration change preceded the observed voltage decline. This temporal association does not establish that the configuration change caused it.",
          "PARTIALLY SUPPORTED",
          [powerEvent.id, ...voltageIds],
        )
      : sufficient
        ? claim(
            "The available evidence supports checking the related power and telemetry sequence; a single root cause is not established.",
            "PARTIALLY SUPPORTED",
            [
              ...telemetrySourceIds,
              ...(powerEvent ? [powerEvent.id] : []),
              ...(historical ? [historical.sourceId] : []),
            ],
          )
        : claim(
            "The available evidence does not establish a cause for this question.",
            "UNSUPPORTED",
            [],
          );
  const recommendation = sufficient
    ? claim(
        `Review the telemetry and event sequence against ${procedure?.title ?? "the applicable operator procedure"}. This is a decision-support suggestion only, not a spacecraft command.`,
        procedure ? "SUPPORTED" : "PARTIALLY SUPPORTED",
        procedure ? [procedure.sourceId] : [],
      )
    : claim(
        "Do not infer a cause from the available records. Obtain relevant subsystem telemetry and operator records before drawing a conclusion.",
        "PARTIALLY SUPPORTED",
        [],
      );

  const evidenceSufficiency = sufficient
    ? asksPhysicalDamage
      ? "PARTIAL"
      : "SUFFICIENT"
    : "INSUFFICIENT";
  const missingEvidence = asksPhysicalDamage
    ? [
        "Direct solar-array imagery or inspection report",
        "Array continuity and deployment telemetry",
        "An operator-confirmed hardware assessment",
      ]
    : sufficient
      ? []
      : [
          "Telemetry or event records directly relevant to the question",
          "An operator procedure or incident report that verifies the proposed explanation",
        ];
  const confidence =
    evidenceSufficiency === "SUFFICIENT"
      ? Math.min(0.86, 0.56 + relevantCount * 0.07)
      : evidenceSufficiency === "PARTIAL"
        ? 0.34
        : 0.12;
  const answerSummary =
    evidenceSufficiency === "INSUFFICIENT"
      ? "INSUFFICIENT EVIDENCE. The available records do not support a reliable answer."
      : `${observedFacts[0]?.text ?? "Relevant operational evidence was retrieved."} ${hypothesis.text}`;
  const id = `INV-${randomUUID().slice(0, 8).toUpperCase()}`;
  const auditId = `AUD-${randomUUID().slice(0, 8).toUpperCase()}`;
  const sourceIds = [
    ...retrievedSources.map((source) => source.sourceId),
    ...observedFacts.flatMap((item) => item.sourceIds),
    ...correlatedEvents.flatMap((item) => item.sourceIds),
    ...historicalContext.flatMap((item) => item.sourceIds),
    ...recommendation.sourceIds,
  ];
  const uniqueSourceIds = [...new Set(sourceIds)];
  const existingSourceIds = new Set(
    retrievedSources.map((source) => source.sourceId),
  );
  const additionalSources = await Promise.all(
    uniqueSourceIds
      .filter((sourceId) => !existingSourceIds.has(sourceId))
      .map(getEvidenceById),
  );
  const citedSources = [
    ...retrievedSources,
    ...additionalSources.filter(
      (source): source is NonNullable<typeof source> => Boolean(source),
    ),
  ];
  const validation =
    [hypothesis, recommendation, ...observedFacts, ...correlatedEvents].some(
      (item) => item.validation === "UNSUPPORTED",
    )
      ? "PARTIAL"
      : "PASSED";

  await db.insert(auditLogsTable).values({
    id: auditId,
    timestamp: new Date(),
    question,
    incidentId,
    retrievedSourceIds: uniqueSourceIds,
    answerSummary,
    recommendation: recommendation.text,
    confidence,
    validation,
    evidenceSufficiency,
    commandIssued: "NONE",
  });

  return {
    id,
    question,
    observedFacts,
    correlatedEvents,
    historicalContext,
    hypothesis,
    recommendation,
    confidence,
    evidenceSufficiency,
    missingEvidence,
    sources: citedSources,
    aiMode: "LOCAL DEMO REASONING",
    auditId,
    commandIssued: "NONE" as const,
  };
}

export async function getIncidentRecord(incidentId: string) {
  const [incident] = await db
    .select()
    .from(incidentsTable)
    .where(eq(incidentsTable.id, incidentId))
    .limit(1);
  return incident;
}

export function serializeAuditRecord(row: typeof auditLogsTable.$inferSelect) {
  return {
    ...row,
    timestamp: row.timestamp.toISOString(),
  };
}

export function serializeInvestigationTime(row: typeof telemetryTable.$inferSelect) {
  return serializeTelemetry(row);
}
