export interface NumericTelemetry {
  batteryVoltage: number;
  solarPower: number;
  batteryTemperature: number;
  communicationSignal: number;
  attitudeError: number;
  cpuUsage: number;
  memoryUsage: number;
  reactionWheelSpeed: number;
}

interface TreeNode {
  size?: number;
  feature?: number;
  split?: number;
  left?: TreeNode;
  right?: TreeNode;
}

function averagePathLength(size: number): number {
  if (size <= 1) return 0;
  if (size === 2) return 1;
  const harmonic = Math.log(size - 1) + 0.5772156649;
  return 2 * harmonic - (2 * (size - 1)) / size;
}

function pathLength(point: number[], node: TreeNode, depth = 0): number {
  if (node.size !== undefined || node.feature === undefined) {
    return depth + averagePathLength(node.size ?? 1);
  }
  return pathLength(
    point,
    point[node.feature] < (node.split ?? 0) ? (node.left ?? { size: 1 }) : (node.right ?? { size: 1 }),
    depth + 1,
  );
}

export class IsolationForest {
  private trees: TreeNode[] = [];
  private sampleSize = 256;
  private threshold = 0.65;
  private randomState = 20261005;

  fit(rows: number[][], treeCount = 80): this {
    if (rows.length < 8 || rows.some((row) => row.length === 0)) {
      throw new Error("Isolation Forest needs at least eight valid baseline rows.");
    }

    this.randomState = 20261005;
    this.sampleSize = Math.min(rows.length, 256);
    const maxDepth = Math.ceil(Math.log2(this.sampleSize));
    this.trees = Array.from({ length: treeCount }, () =>
      this.buildTree(this.sample(rows, this.sampleSize), 0, maxDepth),
    );
    const baselineScores = rows.map((row) => this.rawScore(row));
    baselineScores.sort((a, b) => a - b);
    this.threshold = baselineScores[Math.floor(baselineScores.length * 0.95)] ?? 0.65;
    return this;
  }

  score(point: number[]): number {
    if (this.trees.length === 0) throw new Error("Isolation Forest has not been trained.");
    const raw = this.rawScore(point);
    return Math.max(0, Math.min(1, (raw - this.threshold + 0.12) / 0.34));
  }

  private rawScore(point: number[]): number {
    const meanPath =
      this.trees.reduce((sum, tree) => sum + pathLength(point, tree), 0) /
      this.trees.length;
    return Math.pow(2, -meanPath / averagePathLength(this.sampleSize));
  }

  private sample(rows: number[][], count: number): number[][] {
    const shuffled = [...rows];
    for (let i = shuffled.length - 1; i > 0; i -= 1) {
      const j = Math.floor(this.random() * (i + 1));
      [shuffled[i], shuffled[j]] = [shuffled[j]!, shuffled[i]!];
    }
    return shuffled.slice(0, count);
  }

  private buildTree(rows: number[][], depth: number, maxDepth: number): TreeNode {
    if (depth >= maxDepth || rows.length <= 1) return { size: rows.length };

    const dimensions = rows[0]?.length ?? 0;
    const feature = Math.floor(this.random() * dimensions);
    const values = rows.map((row) => row[feature] ?? 0);
    const min = Math.min(...values);
    const max = Math.max(...values);
    if (min === max) return { size: rows.length };

    const split = min + this.random() * (max - min);
    const leftRows = rows.filter((row) => (row[feature] ?? 0) < split);
    const rightRows = rows.filter((row) => (row[feature] ?? 0) >= split);
    if (leftRows.length === 0 || rightRows.length === 0) return { size: rows.length };

    return {
      feature,
      split,
      left: this.buildTree(leftRows, depth + 1, maxDepth),
      right: this.buildTree(rightRows, depth + 1, maxDepth),
    };
  }

  private random(): number {
    this.randomState =
      (Math.imul(this.randomState, 1_664_525) + 1_013_904_223) >>> 0;
    return this.randomState / 0x1_0000_0000;
  }
}

const rangeFeatures: Array<[keyof NumericTelemetry, number, number]> = [
  ["batteryVoltage", 27.5, 29],
  ["solarPower", 450, 600],
  ["batteryTemperature", 35, 50],
  ["communicationSignal", -60, -45],
  ["attitudeError", 0.05, 0.3],
  ["cpuUsage", 20, 60],
  ["memoryUsage", 30, 70],
  ["reactionWheelSpeed", 1000, 5000],
];

export function telemetryFeatures(
  point: NumericTelemetry,
  history: NumericTelemetry[] = [],
): number[] {
  const raw = rangeFeatures.map(([key, low, high]) =>
    (point[key] - low) / (high - low),
  );
  const prior = history.slice(-12);
  const engineered: number[] = [];

  for (const [key, low, high] of rangeFeatures.slice(0, 4)) {
    const values = prior.map((item) => item[key]);
    const mean =
      values.length > 0
        ? values.reduce((sum, value) => sum + value, 0) / values.length
        : point[key];
    const variance =
      values.length > 1
        ? values.reduce((sum, value) => sum + (value - mean) ** 2, 0) /
          values.length
        : 0;
    const scale = high - low;
    const previous = prior.at(-1)?.[key] ?? point[key];
    engineered.push(
      (point[key] - mean) / scale,
      Math.sqrt(variance) / scale,
      (point[key] - previous) / scale,
      (point[key] - (low + high) / 2) / scale,
    );
  }
  return [...raw, ...engineered];
}

let model: IsolationForest | undefined;

export function trainAnomalyModel(
  baseline: Array<{ point: NumericTelemetry; history?: NumericTelemetry[] }>,
): void {
  model = new IsolationForest().fit(
    baseline.map(({ point, history }) => telemetryFeatures(point, history)),
  );
}

export function detectAnomaly(
  point: NumericTelemetry,
  history: NumericTelemetry[] = [],
): { score: number; status: "NOMINAL" | "WARNING" | "CRITICAL" } {
  if (!model) throw new Error("Anomaly model has not been initialized.");
  const score = model.score(telemetryFeatures(point, history));
  return {
    score: Number(score.toFixed(3)),
    status: score >= 0.78 ? "CRITICAL" : score >= 0.58 ? "WARNING" : "NOMINAL",
  };
}
