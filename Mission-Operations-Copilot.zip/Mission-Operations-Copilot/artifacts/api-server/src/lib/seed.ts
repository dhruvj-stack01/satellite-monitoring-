import { asc } from "drizzle-orm";
import {
  db,
  documentChunksTable,
  documentsTable,
  incidentsTable,
  missionEventsTable,
  spacecraftTable,
  telemetryTable,
} from "@workspace/db";
import { embedText } from "./evidence-search";
import { trainAnomalyModel, type NumericTelemetry } from "./isolation-forest";

const spacecraft = {
  id: "ORBIT-X1",
  name: "ORBIT-X1",
  status: "NOMINAL",
  sourceLabel: "SIMULATED LIVE TELEMETRY",
  lastContactAt: new Date(),
};

const documents = [
  {
    id: "P-017",
    title: "Low Voltage Investigation Procedure",
    sourceType: "PROCEDURE",
    content:
      "P-017 — Low Voltage Investigation Procedure. Confirm the battery voltage trend across multiple samples and compare it with the operating band of 27.5–29.0 V. Review solar power, battery temperature, and recent power configuration events in the same time window. Compare the pattern with historical incidents. This is an operator review procedure; it does not authorize autonomous commands or configuration changes. A temporal relationship is not proof of cause.",
  },
  {
    id: "P-021",
    title: "Communication Degradation Procedure",
    sourceType: "PROCEDURE",
    content:
      "P-021 — Communication Degradation Procedure. Compare signal strength against the normal -60 to -45 dBm range. Check timestamp alignment with battery and power telemetry, then inspect ground-station visibility and link-quality records. If those records are absent, report the cause as unknown. This procedure is for human review only and cannot issue a spacecraft command.",
  },
  {
    id: "P-031",
    title: "Power Configuration Review Procedure",
    sourceType: "PROCEDURE",
    content:
      "P-031 — Power Configuration Review Procedure. Inspect the configuration event log and verify the timing against voltage, solar-array output, and battery temperature samples. Distinguish an observed sequence from a causal conclusion. Confirm configuration details with an authorized operator before any change. The copilot only recommends review; it does not control the vehicle.",
  },
  {
    id: "INC-008",
    title: "Historical Battery Anomaly",
    sourceType: "HISTORICAL INCIDENT",
    occurredAt: new Date(Date.now() - 1000 * 60 * 60 * 24 * 43),
    content:
      "INC-008 — Resolved medium-severity battery-voltage decline. Telemetry moved from 28.6 V to 25.4 V shortly after a power configuration event. Solar output was variable in the same period. The investigation established temporal correlation, not causation. Operators reviewed the configuration history and solar-power telemetry using P-017. No evidence in this record establishes a physical solar-array break.",
  },
  {
    id: "INC-013",
    title: "Historical Power Subsystem Anomaly",
    sourceType: "HISTORICAL INCIDENT",
    occurredAt: new Date(Date.now() - 1000 * 60 * 60 * 24 * 21),
    content:
      "INC-013 — Resolved high-severity power subsystem anomaly. Battery voltage declined during a load-configuration transition and recovered after the transition ended. Solar-power readings remained available but did not alone explain the decline. The incident supports reviewing configuration events alongside battery and solar telemetry; it does not prove the same cause in a different event.",
  },
  {
    id: "INC-021",
    title: "Historical Communication Degradation",
    sourceType: "HISTORICAL INCIDENT",
    occurredAt: new Date(Date.now() - 1000 * 60 * 60 * 24 * 8),
    content:
      "INC-021 — Resolved medium-severity communication degradation. Signal strength fell below -60 dBm during an interval with battery-voltage variation. Ground-station visibility records were incomplete, so the root cause remained undetermined. Operators compared communication and power telemetry under P-021. This record does not establish a physical hardware failure.",
  },
  {
    id: "INC-006",
    title: "Historical Attitude Error Increase",
    sourceType: "HISTORICAL INCIDENT",
    occurredAt: new Date(Date.now() - 1000 * 60 * 60 * 24 * 72),
    content:
      "INC-006 — Resolved low-severity attitude-error increase. Attitude error rose above its usual range while reaction-wheel speed increased. The available evidence supported a correlated control-load observation, but no direct cause was proven. Operators reviewed the attitude and wheel telemetry trend.",
  },
  {
    id: "INC-018",
    title: "Historical Battery Thermal Warning",
    sourceType: "HISTORICAL INCIDENT",
    occurredAt: new Date(Date.now() - 1000 * 60 * 60 * 24 * 15),
    content:
      "INC-018 — Resolved medium-severity battery-temperature warning. Battery temperature reached 51.2 °C during a period of elevated processor load. The incident report recommended checking thermal telemetry and load history. It did not identify physical damage or authorize a configuration change.",
  },
  {
    id: "SAFE-001",
    title: "Mission Operations Safety Manual",
    sourceType: "SAFETY MANUAL",
    content:
      "Mission Operations Safety Manual. The copilot is decision support only. It has no telemetry uplink, command encoder, or vehicle-control interface. Separate observed facts from hypotheses and recommendations. Cite supporting sources for material claims. State when the evidence is incomplete, and abstain rather than infer an unobserved physical condition. A human operator remains responsible for all mission decisions.",
  },
];

function baselinePoint(index: number): NumericTelemetry {
  return {
    batteryVoltage:
      28.45 + 0.22 * Math.sin(index / 47) + 0.035 * Math.sin(index * 1.77),
    solarPower: 525 + 36 * Math.sin(index / 38) + 5 * Math.sin(index * 1.21),
    batteryTemperature:
      42.5 + 3.1 * Math.sin(index / 75) + 0.35 * Math.sin(index * 1.43),
    communicationSignal:
      -52 + 2.2 * Math.sin(index / 29) + 0.3 * Math.sin(index * 1.31),
    attitudeError: 0.17 + 0.035 * Math.sin(index / 21),
    cpuUsage: 38 + 11 * Math.sin(index / 16),
    memoryUsage: 49 + 9 * Math.sin(index / 95),
    reactionWheelSpeed: 2800 + 620 * Math.sin(index / 24),
  };
}

function splitContent(content: string): string[] {
  const sentences = content.split(/(?<=[.!?])\s+/);
  const chunks: string[] = [];
  let current = "";
  for (const sentence of sentences) {
    if (current.length + sentence.length > 460 && current.length > 0) {
      chunks.push(current.trim());
      current = "";
    }
    current += `${sentence} `;
  }
  if (current.trim()) chunks.push(current.trim());
  return chunks;
}

function vectorFor(row: typeof telemetryTable.$inferSelect): NumericTelemetry {
  return {
    batteryVoltage: row.batteryVoltage,
    solarPower: row.solarPower,
    batteryTemperature: row.batteryTemperature,
    communicationSignal: row.communicationSignal,
    attitudeError: row.attitudeError,
    cpuUsage: row.cpuUsage,
    memoryUsage: row.memoryUsage,
    reactionWheelSpeed: row.reactionWheelSpeed,
  };
}

export async function seedDatabase(): Promise<void> {
  const existingSpacecraft = await db
    .select({ id: spacecraftTable.id })
    .from(spacecraftTable)
    .limit(1);

  if (existingSpacecraft.length === 0) {
    await db.insert(spacecraftTable).values(spacecraft);
    const now = Date.now();
    const records = Array.from({ length: 512 }, (_, index) => {
      const point = baselinePoint(index);
      return {
        id: `TEL-${String(index + 1).padStart(3, "0")}`,
        spacecraftId: spacecraft.id,
        timestamp: new Date(now - (511 - index) * 60_000),
        ...point,
        anomalyScore: 0.02,
        anomalyStatus: "NOMINAL",
        sourceLabel: "SIMULATED LIVE TELEMETRY",
      };
    });
    for (let offset = 0; offset < records.length; offset += 100) {
      await db
        .insert(telemetryTable)
        .values(records.slice(offset, offset + 100))
        .onConflictDoNothing();
    }

    const nowDate = new Date();
    const eventRows = Array.from({ length: 24 }, (_, index) => ({
      id: `EV-${String(101 + index).padStart(3, "0")}`,
      eventType:
        index % 4 === 0
          ? "POWER_REVIEW"
          : index % 4 === 1
            ? "THERMAL_SAMPLE"
            : index % 4 === 2
              ? "LINK_QUALITY_SAMPLE"
              : "ATTITUDE_CHECK",
      subsystem:
        index % 4 === 0
          ? "POWER"
          : index % 4 === 1
            ? "THERMAL"
            : index % 4 === 2
              ? "COMMUNICATION"
              : "ATTITUDE",
      description:
        index % 4 === 0
          ? "Power subsystem configuration review recorded."
          : index % 4 === 1
            ? "Battery thermal telemetry sample recorded."
            : index % 4 === 2
              ? "Communication link quality sample recorded."
              : "Attitude subsystem check recorded.",
      occurredAt: new Date(nowDate.getTime() - index * 3_600_000),
      severity: index % 7 === 0 ? "WARNING" : "INFO",
      sourceLabel: "SIMULATED EVENT HISTORY",
    }));
    await db.insert(missionEventsTable).values(eventRows).onConflictDoNothing();

    const incidentRows = [
      {
        id: "INC-008",
        title: "Battery Voltage Decline Following Power Configuration Event",
        severity: "MEDIUM",
        status: "RESOLVED",
        summary:
          "Battery voltage fell after a configuration event; timing was observed but causation was not established.",
        openedAt: new Date(Date.now() - 1000 * 60 * 60 * 24 * 43),
      },
      {
        id: "INC-013",
        title: "Power Subsystem Load Transition Anomaly",
        severity: "HIGH",
        status: "RESOLVED",
        summary:
          "Voltage varied during a load transition; operators reviewed power and solar telemetry.",
        openedAt: new Date(Date.now() - 1000 * 60 * 60 * 24 * 21),
      },
      {
        id: "INC-021",
        title: "Communication Degradation with Battery Variation",
        severity: "MEDIUM",
        status: "RESOLVED",
        summary:
          "Signal strength degraded during battery variation; ground-station evidence was incomplete.",
        openedAt: new Date(Date.now() - 1000 * 60 * 60 * 24 * 8),
      },
      {
        id: "INC-006",
        title: "Attitude Error Increase with Reaction-Wheel Load",
        severity: "LOW",
        status: "RESOLVED",
        summary:
          "Attitude error and reaction-wheel speed increased together without a proven root cause.",
        openedAt: new Date(Date.now() - 1000 * 60 * 60 * 24 * 72),
      },
      {
        id: "INC-018",
        title: "Battery Thermal Warning During Processor Load",
        severity: "MEDIUM",
        status: "RESOLVED",
        summary:
          "Battery temperature reached 51.2 °C during elevated processor load.",
        openedAt: new Date(Date.now() - 1000 * 60 * 60 * 24 * 15),
      },
    ];
    await db
      .insert(incidentsTable)
      .values(incidentRows.map((row) => ({ ...row, updatedAt: row.openedAt })))
      .onConflictDoNothing();

    for (const document of documents) {
      await db
        .insert(documentsTable)
        .values({
          ...document,
          occurredAt: document.occurredAt ?? null,
          sourceLabel: document.sourceType.includes("HISTORICAL")
            ? "HISTORICAL DEMO DATA"
            : "DEMO PROCEDURE LIBRARY",
        })
        .onConflictDoNothing();

      const chunks = splitContent(document.content);
      await db
        .insert(documentChunksTable)
        .values(
          chunks.map((content, chunkIndex) => ({
            id: `${document.id}-CH${String(chunkIndex + 1).padStart(2, "0")}`,
            documentId: document.id,
            chunkIndex,
            content,
            embedding: embedText(content),
          })),
        )
        .onConflictDoNothing();
    }
  }

  const baseline = await db
    .select()
    .from(telemetryTable)
    .orderBy(asc(telemetryTable.timestamp))
    .limit(512);
  if (baseline.length >= 8) {
    trainAnomalyModel(
      baseline.map((row, index) => ({
        point: vectorFor(row),
        history: baseline.slice(Math.max(0, index - 12), index).map(vectorFor),
      })),
    );
  }
}
