import type {
  incidentsTable,
  missionEventsTable,
  telemetryTable,
} from "@workspace/db";

type Telemetry = typeof telemetryTable.$inferSelect;
type MissionEvent = typeof missionEventsTable.$inferSelect;
type Incident = typeof incidentsTable.$inferSelect;

export function serializeTelemetry(row: Telemetry) {
  return {
    ...row,
    timestamp: row.timestamp.toISOString(),
  };
}

export function serializeEvent(row: MissionEvent) {
  return {
    ...row,
    occurredAt: row.occurredAt.toISOString(),
  };
}

export function serializeIncident(row: Incident) {
  return {
    ...row,
    openedAt: row.openedAt.toISOString(),
    updatedAt: row.updatedAt.toISOString(),
  };
}
