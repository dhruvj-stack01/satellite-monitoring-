import { createHash, randomUUID } from "node:crypto";
import type { Server as HttpServer } from "node:http";
import type { Duplex } from "node:stream";
import { and, desc, eq, gte, lte } from "drizzle-orm";
import {
  db,
  incidentsTable,
  missionEventsTable,
  spacecraftTable,
  telemetryTable,
} from "@workspace/db";
import { logger } from "./logger";
import { detectAnomaly, type NumericTelemetry } from "./isolation-forest";
import { serializeEvent, serializeTelemetry } from "./serializers";

const SOURCE_LABEL = "SIMULATED LIVE TELEMETRY";
const spacecraftId = "ORBIT-X1";
const clients = new Set<Duplex>();

let running = true;
let replayActive = false;
let timer: NodeJS.Timeout | undefined;
let tick = 0;
let ticking = false;

function encodeFrame(opcode: number, payload: Buffer): Buffer {
  const header =
    payload.length < 126
      ? Buffer.from([0x80 | opcode, payload.length])
      : payload.length < 65_536
        ? Buffer.from([0x80 | opcode, 126, payload.length >> 8, payload.length & 0xff])
        : Buffer.from([
            0x80 | opcode,
            127,
            0,
            0,
            0,
            0,
            (payload.length >> 24) & 0xff,
            (payload.length >> 16) & 0xff,
            (payload.length >> 8) & 0xff,
            payload.length & 0xff,
          ]);
  return Buffer.concat([header, payload]);
}

function sendToClient(socket: Duplex, payload: unknown): void {
  if (!socket.destroyed && socket.writable) {
    socket.write(encodeFrame(1, Buffer.from(JSON.stringify(payload))));
  }
}

export function broadcastTelemetry(payload: unknown): void {
  for (const client of clients) sendToClient(client, payload);
}

export function attachTelemetryWebSocket(server: HttpServer): void {
  server.on("upgrade", (request, socket) => {
    const pathname = new URL(request.url ?? "/", "http://localhost").pathname;
    if (pathname !== "/api/ws/telemetry") {
      socket.destroy();
      return;
    }
    const key = request.headers["sec-websocket-key"];
    if (typeof key !== "string") {
      socket.destroy();
      return;
    }
    const accept = createHash("sha1")
      .update(`${key}258EAFA5-E914-47DA-95CA-C5AB0DC85B11`)
      .digest("base64");
    socket.write(
      [
        "HTTP/1.1 101 Switching Protocols",
        "Upgrade: websocket",
        "Connection: Upgrade",
        `Sec-WebSocket-Accept: ${accept}`,
        "\r\n",
      ].join("\r\n"),
    );
    request.socket.setNoDelay(true);
    clients.add(socket);
    socket.on("close", () => clients.delete(socket));
    socket.on("error", () => clients.delete(socket));
    socket.on("data", (data: Buffer) => {
      const opcode = (data[0] ?? 0) & 0x0f;
      if (opcode === 8) {
        socket.end(encodeFrame(8, Buffer.alloc(0)));
        clients.delete(socket);
      } else if (opcode === 9) {
        socket.write(encodeFrame(10, Buffer.alloc(0)));
      }
    });
    sendToClient(socket, { type: "connection", status: "connected", sourceLabel: SOURCE_LABEL });
    void db
      .select()
      .from(telemetryTable)
      .orderBy(desc(telemetryTable.timestamp))
      .limit(1)
      .then(([latest]) => {
        if (latest) sendToClient(socket, { type: "telemetry", telemetry: serializeTelemetry(latest) });
      })
      .catch((error: unknown) => logger.error({ error }, "Could not hydrate telemetry websocket"));
  });
}

function baselineValue(previous: NumericTelemetry, step: number): NumericTelemetry {
  const easeIntoBand = (
    value: number,
    lower: number,
    upper: number,
    recoveryStep: number,
    nominalDelta: number,
  ) => {
    if (value < lower) return Math.min(lower, value + recoveryStep);
    if (value > upper) return Math.max(upper, value - recoveryStep);
    return value + nominalDelta;
  };
  return {
    batteryVoltage: Math.max(
      27.5,
      Math.min(
        29,
        easeIntoBand(
          previous.batteryVoltage,
          27.8,
          28.8,
          0.12,
          0.008 * Math.sin(step / 4) + 0.002 * Math.cos(step),
        ),
      ),
    ),
    solarPower: Math.max(
      450,
      Math.min(
        600,
        easeIntoBand(
          previous.solarPower,
          480,
          570,
          12,
          2.5 * Math.sin(step / 7) + 0.7 * Math.cos(step / 2),
        ),
      ),
    ),
    batteryTemperature: Math.max(
      35,
      Math.min(
        50,
        easeIntoBand(
          previous.batteryTemperature,
          39,
          46,
          0.35,
          0.08 * Math.sin(step / 12),
        ),
      ),
    ),
    communicationSignal: Math.max(
      -60,
      Math.min(
        -45,
        easeIntoBand(
          previous.communicationSignal,
          -56,
          -48,
          1.2,
          0.12 * Math.sin(step / 3),
        ),
      ),
    ),
    attitudeError: Math.max(
      0.05,
      Math.min(
        0.3,
        easeIntoBand(
          previous.attitudeError,
          0.08,
          0.28,
          0.018,
          0.0015 * Math.sin(step / 3),
        ),
      ),
    ),
    cpuUsage: Math.max(
      20,
      Math.min(
        60,
        easeIntoBand(previous.cpuUsage, 25, 54, 3, 0.6 * Math.sin(step / 3)),
      ),
    ),
    memoryUsage: Math.max(
      30,
      Math.min(
        70,
        easeIntoBand(previous.memoryUsage, 36, 64, 1.2, 0.18 * Math.sin(step / 10)),
      ),
    ),
    reactionWheelSpeed: Math.max(
      1000,
      Math.min(
        5000,
        easeIntoBand(previous.reactionWheelSpeed, 1500, 4200, 120, 18 * Math.sin(step / 4)),
      ),
    ),
  };
}

async function readHistory(): Promise<NumericTelemetry[]> {
  const rows = await db
    .select()
    .from(telemetryTable)
    .orderBy(desc(telemetryTable.timestamp))
    .limit(16);
  return rows
    .reverse()
    .map((row) => ({
      batteryVoltage: row.batteryVoltage,
      solarPower: row.solarPower,
      batteryTemperature: row.batteryTemperature,
      communicationSignal: row.communicationSignal,
      attitudeError: row.attitudeError,
      cpuUsage: row.cpuUsage,
      memoryUsage: row.memoryUsage,
      reactionWheelSpeed: row.reactionWheelSpeed,
    }));
}

async function writeTelemetry(
  point: NumericTelemetry,
  broadcast = true,
  id?: string,
): Promise<ReturnType<typeof serializeTelemetry>> {
  const history = await readHistory();
  const detection = detectAnomaly(point, history);
  const [row] = await db
    .insert(telemetryTable)
    .values({
      id: id ?? `TEL-${Date.now()}`,
      spacecraftId,
      timestamp: new Date(),
      ...point,
      anomalyScore: detection.score,
      anomalyStatus: detection.status,
      sourceLabel: SOURCE_LABEL,
    })
    .returning();
  if (!row) throw new Error("Telemetry insert returned no record.");

  await db
    .update(spacecraftTable)
    .set({
      status: detection.status,
      sourceLabel: SOURCE_LABEL,
      lastContactAt: row.timestamp,
    })
    .where(eq(spacecraftTable.id, spacecraftId));

  const serialized = serializeTelemetry(row);
  if (broadcast) {
    broadcastTelemetry({
      type: "telemetry",
      telemetry: serialized,
      sourceLabel: SOURCE_LABEL,
    });
  }
  if (!replayActive && detection.score >= 0.58) {
    await correlateAndCreateIncident(serialized);
  }
  return serialized;
}

async function writeReplayEvent(
  id: string,
  eventType: string,
  subsystem: string,
  description: string,
  severity: "INFO" | "WARNING" | "HIGH" | "CRITICAL",
): Promise<void> {
  const [row] = await db
    .insert(missionEventsTable)
    .values({
      id,
      eventType,
      subsystem,
      description,
      occurredAt: new Date(),
      severity,
      sourceLabel: "SIMULATED INCIDENT REPLAY",
    })
    .onConflictDoUpdate({
      target: missionEventsTable.id,
      set: {
        eventType,
        subsystem,
        description,
        occurredAt: new Date(),
        severity,
        sourceLabel: "SIMULATED INCIDENT REPLAY",
      },
    })
    .returning();
  if (row) broadcastTelemetry({ type: "replay_event", event: serializeEvent(row) });
}

async function simulationTick(): Promise<void> {
  if (!running || replayActive || ticking) return;
  ticking = true;
  try {
    const history = await readHistory();
    const latest = history.at(-1) ?? {
      batteryVoltage: 28.5,
      solarPower: 520,
      batteryTemperature: 43,
      communicationSignal: -51,
      attitudeError: 0.18,
      cpuUsage: 38,
      memoryUsage: 50,
      reactionWheelSpeed: 2800,
    };
    tick += 1;
    await writeTelemetry(baselineValue(latest, tick));
  } catch (error) {
    logger.error({ error }, "Simulated telemetry tick failed");
  } finally {
    ticking = false;
  }
}

export function initializeSimulation(): void {
  running = true;
  if (!timer) timer = setInterval(() => void simulationTick(), 1500);
}

export function startSimulation() {
  running = true;
  if (!timer) timer = setInterval(() => void simulationTick(), 1500);
  void simulationTick();
  return getSimulationStatus();
}

export function stopSimulation() {
  running = false;
  if (timer) clearInterval(timer);
  timer = undefined;
  return getSimulationStatus();
}

export function getSimulationStatus() {
  return {
    running,
    sourceLabel: SOURCE_LABEL,
    liveConnection: false,
    replayActive,
  };
}

const delay = (ms: number) => new Promise<void>((resolve) => setTimeout(resolve, ms));

export function replayCriticalIncident(): { accepted: boolean; incidentId: string } {
  if (replayActive) return { accepted: false, incidentId: "INC-024" };
  replayActive = true;
  void (async () => {
    try {
      broadcastTelemetry({ type: "replay_started", incidentId: "INC-024" });
      await writeTelemetry(
        {
          batteryVoltage: 28.5,
          solarPower: 520,
          batteryTemperature: 43,
          communicationSignal: -51,
          attitudeError: 0.18,
          cpuUsage: 38,
          memoryUsage: 50,
          reactionWheelSpeed: 2800,
        },
        true,
        "TEL-1031",
      );
      broadcastTelemetry({ type: "replay_event", stage: "T+0", kind: "NORMAL" });
      await delay(1600);

      await writeReplayEvent(
        "EV-204",
        "CONFIGURATION_CHANGE",
        "POWER",
        "Power configuration changed.",
        "INFO",
      );
      broadcastTelemetry({
        type: "replay_event",
        stage: "T+5",
        kind: "EVENT",
        sourceId: "EV-204",
        description: "Power configuration changed.",
      });
      await delay(1600);

      await writeTelemetry(
        {
          batteryVoltage: 26.9,
          solarPower: 405,
          batteryTemperature: 44.8,
          communicationSignal: -54,
          attitudeError: 0.24,
          cpuUsage: 48,
          memoryUsage: 52,
          reactionWheelSpeed: 3300,
        },
        true,
        "TEL-1032",
      );
      broadcastTelemetry({ type: "replay_event", stage: "T+8", kind: "WARNING" });
      await delay(1600);

      await writeTelemetry(
        {
          batteryVoltage: 24.8,
          solarPower: 260,
          batteryTemperature: 51.4,
          communicationSignal: -58,
          attitudeError: 0.36,
          cpuUsage: 66,
          memoryUsage: 69,
          reactionWheelSpeed: 4680,
        },
        true,
        "TEL-1033",
      );
      broadcastTelemetry({ type: "replay_event", stage: "T+11", kind: "CRITICAL" });
      await delay(1400);

      await writeReplayEvent(
        "EV-205",
        "LINK_QUALITY_DROP",
        "COMMUNICATION",
        "Communication signal degraded following the battery-voltage decline.",
        "WARNING",
      );
      await writeTelemetry(
        {
          batteryVoltage: 24.6,
          solarPower: 245,
          batteryTemperature: 52.1,
          communicationSignal: -66,
          attitudeError: 0.39,
          cpuUsage: 73,
          memoryUsage: 72,
          reactionWheelSpeed: 4920,
        },
        true,
        "TEL-1034",
      );
      broadcastTelemetry({ type: "replay_event", stage: "T+13", kind: "COMMUNICATION" });
      await delay(1400);

      await writeReplayEvent(
        "EV-206",
        "COMMUNICATION_WARNING",
        "COMMUNICATION",
        "Communication warning recorded; cause is not established.",
        "HIGH",
      );
      broadcastTelemetry({ type: "replay_event", stage: "T+15", kind: "WARNING" });
      await delay(1400);

      const finalTelemetry = await writeTelemetry(
        {
          batteryVoltage: 24.3,
          solarPower: 230,
          batteryTemperature: 52.8,
          communicationSignal: -69,
          attitudeError: 0.42,
          cpuUsage: 81,
          memoryUsage: 75,
          reactionWheelSpeed: 5120,
        },
        true,
        "TEL-1035",
      );
      broadcastTelemetry({
        type: "replay_event",
        stage: "T+17",
        kind: "ANOMALY",
        anomalyScore: finalTelemetry.anomalyScore,
      });
      await delay(1400);

      const now = new Date();
      const [incident] = await db
        .insert(incidentsTable)
        .values({
          id: "INC-024",
          title: "Battery Voltage Degradation Following Power Configuration Event",
          severity: "HIGH",
          status: "ACTIVE",
          summary:
            "Simulated replay: voltage decline followed a power configuration event, then communication quality degraded. Temporal correlation does not establish cause.",
          openedAt: now,
          updatedAt: now,
        })
        .onConflictDoUpdate({
          target: incidentsTable.id,
          set: {
            severity: "HIGH",
            status: "ACTIVE",
            updatedAt: now,
            summary:
              "Simulated replay: voltage decline followed a power configuration event, then communication quality degraded. Temporal correlation does not establish cause.",
          },
        })
        .returning();
      broadcastTelemetry({
        type: "incident_created",
        incident: incident
          ? {
              ...incident,
              openedAt: incident.openedAt.toISOString(),
              updatedAt: incident.updatedAt.toISOString(),
            }
          : { id: "INC-024" },
      });
      await db
        .update(spacecraftTable)
        .set({ status: "CRITICAL", lastContactAt: now })
        .where(eq(spacecraftTable.id, spacecraftId));
    } catch (error) {
      logger.error({ error }, "Incident replay failed");
      broadcastTelemetry({ type: "replay_error", message: "Incident replay could not complete." });
    } finally {
      replayActive = false;
      if (running && !timer) timer = setInterval(() => void simulationTick(), 1500);
    }
  })();
  return { accepted: true, incidentId: "INC-024" };
}

export async function correlateNearbyEvents(timestamp: Date) {
  const start = new Date(timestamp.getTime() - 5 * 60_000);
  const end = new Date(timestamp.getTime() + 5 * 60_000);
  return db
    .select()
    .from(missionEventsTable)
    .where(and(gte(missionEventsTable.occurredAt, start), lte(missionEventsTable.occurredAt, end)))
    .limit(40)
    .then((rows) => rows);
}

export async function getReplayIncident() {
  const [incident] = await db
    .select()
    .from(incidentsTable)
    .where(eq(incidentsTable.id, "INC-024"))
    .limit(1);
  return incident;
}

export async function correlateAndCreateIncident(
  telemetry: ReturnType<typeof serializeTelemetry>,
): Promise<void> {
  if (telemetry.anomalyScore < 0.78 || replayActive) return;
  const nearby = await correlateNearbyEvents(new Date(telemetry.timestamp));
  const related = nearby.filter((event) =>
    ["POWER", "THERMAL", "COMMUNICATION", "ATTITUDE"].includes(event.subsystem) &&
    (event.severity === "HIGH" ||
      event.severity === "CRITICAL" ||
      /CONFIGURATION_CHANGE|LINK_QUALITY_DROP|WARNING|ALERT/.test(event.eventType)),
  );
  if (related.length === 0) return;

  const active = await db
    .select({ id: incidentsTable.id })
    .from(incidentsTable)
    .where(eq(incidentsTable.status, "ACTIVE"))
    .limit(1);
  if (active.length > 0) return;

  const isPower = related.some((event) => event.subsystem === "POWER");
  const now = new Date();
  const incidentId = `INC-AUTO-${randomUUID().slice(0, 6).toUpperCase()}`;
  const [incident] = await db
    .insert(incidentsTable)
    .values({
      id: incidentId,
      title: isPower
        ? "Telemetry Anomaly Correlated with Power Event"
        : "Telemetry Anomaly with Nearby Mission Event",
      severity: telemetry.anomalyStatus === "CRITICAL" ? "HIGH" : "MEDIUM",
      status: "ACTIVE",
      summary:
        `Anomaly score ${telemetry.anomalyScore.toFixed(2)} coincided with ` +
        `${related.length} event(s) inside a ±5 minute correlation window. ` +
        "Temporal proximity does not establish causation.",
      openedAt: now,
      updatedAt: now,
    })
    .returning();
  if (incident) {
    broadcastTelemetry({
      type: "incident_created",
      incident: {
        ...incident,
        openedAt: incident.openedAt.toISOString(),
        updatedAt: incident.updatedAt.toISOString(),
      },
      correlatedEventIds: related.map((event) => event.id),
      telemetryId: telemetry.id,
    });
  }
}

export function newEventId(): string {
  return `EV-${randomUUID().slice(0, 8).toUpperCase()}`;
}
