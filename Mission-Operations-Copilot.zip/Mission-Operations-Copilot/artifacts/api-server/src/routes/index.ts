import { Router, type IRouter } from "express";
import healthRouter from "./health";
import investigationRouter from "./investigation";
import missionRouter from "./mission";
import simulationRouter from "./simulation";

const router: IRouter = Router();

router.use(healthRouter);
router.use(missionRouter);
router.use(investigationRouter);
router.use(simulationRouter);

export default router;
