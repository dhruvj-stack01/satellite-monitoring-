import { Router, type IRouter } from "express";
import {
  InvestigateBody,
  InvestigateIncidentBody,
  InvestigateIncidentParams,
  InvestigateIncidentResponse,
  InvestigateResponse,
  SearchEvidenceBody,
  SearchEvidenceResponse,
} from "@workspace/api-zod";
import { searchEvidence } from "../lib/evidence";
import { investigateQuestion } from "../lib/investigation";

const router: IRouter = Router();

router.post("/investigate", async (req, res): Promise<void> => {
  const body = InvestigateBody.safeParse(req.body);
  if (!body.success) {
    res.status(400).json({ error: body.error.message });
    return;
  }
  const result = await investigateQuestion(body.data.question, body.data.incidentId ?? null);
  res.json(InvestigateResponse.parse(result));
});

router.post("/incidents/:incident_id/investigate", async (req, res): Promise<void> => {
  const params = InvestigateIncidentParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  const body = InvestigateIncidentBody.safeParse(req.body);
  if (!body.success) {
    res.status(400).json({ error: body.error.message });
    return;
  }
  const result = await investigateQuestion(
    body.data.question,
    params.data.incident_id,
  );
  res.json(InvestigateIncidentResponse.parse(result));
});

router.post("/rag/search", async (req, res): Promise<void> => {
  const body = SearchEvidenceBody.safeParse(req.body);
  if (!body.success) {
    res.status(400).json({ error: body.error.message });
    return;
  }
  const results = await searchEvidence(body.data.query, body.data.limit ?? 8);
  res.json(SearchEvidenceResponse.parse(results));
});

export default router;
