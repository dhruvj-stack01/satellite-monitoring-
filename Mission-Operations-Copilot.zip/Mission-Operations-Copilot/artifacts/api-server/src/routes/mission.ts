import { randomUUID } from "node:crypto";
import { asc, desc, eq } from "drizzle-orm";
import { Router, type IRouter } from "express";
import {
  AuditRecord,
  GetAuditResponse,
  GetDashboardResponse,
  GetEventsResponse,
  GetEvidenceParams,
  GetEvidenceResponse,
  GetIncidentParams,
  GetIncidentResponse,
  GetIncidentsResponse,
  GetLatestTelemetryResponse,
  GetSimilarIncidentsParams,
  GetSimilarIncidentsResponse,
  GetSpacecraftResponse,
  GetTelemetryHistoryQueryParams,
  GetTelemetryHistoryResponse,
  IngestEventBody,
  IngestEventResponse,
  IngestTelemetryBody,
  IngestTelemetryResponse,
  SimilarIncident,
  SubmitContactBody,
  SubmitContactResponse,
} from "@workspace/api-zod";
import {
  auditLogsTable,
  contactMessagesTable,
  db,
  incidentsTable,
  missionEventsTable,
  spacecraftTable,
  telemetryTable,
} from "@workspace/db";
import { getEvidenceById } from "../lib/evidence";
import {
  investigateQuestion,
  serializeAuditRecord,
  getIncidentRecord,
} from "../lib/investigation";
import { detectAnomaly, type NumericTelemetry } from "../lib/isolation-forest";
import { serializeEvent, serializeIncident, serializeTelemetry } from "../lib/serializers";
import {
  broadcastTelemetry,
  correlateAndCreateIncident,
  getSimulationStatus,
} from "../lib/simulation";
import { hybridScores, tokenize } from "../lib/evidence-search";

const router: IRouter = Router();

router.get("/dashboard", async (_req, res): Promise<void> => {
  const [spacecraft, latest, activeIncidents, recentEvents] = await Promise.all([
    db.select().from(spacecraftTable).limit(1),
    db.select().from(telemetryTable).orderBy(desc(telemetryTable.timestamp)).limit(1),
    db.select({ id: incidentsTable.id }).from(incidentsTable).where(eq(incidentsTable.status, "ACTIVE")),
    db.select().from(missionEventsTable).orderBy(desc(missionEventsTable.occurredAt)).limit(6),
  ]);
  const summary = {
    spacecraft: spacecraft[0]
      ? { ...spacecraft[0], lastContactAt: spacecraft[0].lastContactAt.toISOString() }
      : {
          id: "ORBIT-X1",
          name: "ORBIT-X1",
          status: "NOMINAL",
          sourceLabel: "SIMULATED LIVE TELEMETRY",
          lastContactAt: new Date().toISOString(),
        },
    simulation: getSimulationStatus(),
    latestTelemetry: latest[0] ? serializeTelemetry(latest[0]) : undefined,
    activeIncidentCount: activeIncidents.length,
    recentEvents: recentEvents.map(serializeEvent),
  };
  res.json(GetDashboardResponse.parse(summary));
});

router.get("/spacecraft", async (_req, res): Promise<void> => {
  const rows = await db.select().from(spacecraftTable);
  res.json(
    GetSpacecraftResponse.parse(
      rows.map((row) => ({ ...row, lastContactAt: row.lastContactAt.toISOString() })),
    ),
  );
});

router.get("/telemetry/latest", async (_req, res): Promise<void> => {
  const [row] = await db
    .select()
    .from(telemetryTable)
    .orderBy(desc(telemetryTable.timestamp))
    .limit(1);
  if (!row) {
    res.status(503).json({ error: "Telemetry has not been initialized." });
    return;
  }
  res.json(GetLatestTelemetryResponse.parse(serializeTelemetry(row)));
});

router.get("/telemetry/history", async (req, res): Promise<void> => {
  const query = GetTelemetryHistoryQueryParams.safeParse(req.query);
  if (!query.success) {
    res.status(400).json({ error: query.error.message });
    return;
  }
  const rows = await db
    .select()
    .from(telemetryTable)
    .orderBy(desc(telemetryTable.timestamp))
    .limit(query.data.limit ?? 240);
  res.json(GetTelemetryHistoryResponse.parse(rows.map(serializeTelemetry)));
});

router.post("/telemetry/ingest", async (req, res): Promise<void> => {
  const body = IngestTelemetryBody.safeParse(req.body);
  if (!body.success) {
    res.status(400).json({ error: body.error.message });
    return;
  }

  const payload = body.data;
  const sourceLabel =
    payload.sourceLabel === "PUBLIC HISTORICAL"
      ? "PUBLIC HISTORICAL DATA"
      : payload.sourceLabel;
  const historical = await db
    .select()
    .from(telemetryTable)
    .orderBy(desc(telemetryTable.timestamp))
    .limit(16);
  const context: NumericTelemetry[] = historical.reverse().map((row) => ({
    batteryVoltage: row.batteryVoltage,
    solarPower: row.solarPower,
    batteryTemperature: row.batteryTemperature,
    communicationSignal: row.communicationSignal,
    attitudeError: row.attitudeError,
    cpuUsage: row.cpuUsage,
    memoryUsage: row.memoryUsage,
    reactionWheelSpeed: row.reactionWheelSpeed,
  }));
  const inserted = [];
  for (const record of payload.records) {
    const { spacecraftId, timestamp, ...point } = record;
    const detection = detectAnomaly(point, context);
    const [row] = await db
      .insert(telemetryTable)
      .values({
        id: `TEL-UP-${randomUUID().slice(0, 10).toUpperCase()}`,
        spacecraftId,
        timestamp: new Date(timestamp),
        ...point,
        anomalyScore: detection.score,
        anomalyStatus: detection.status,
        sourceLabel,
      })
      .returning();
    if (row) inserted.push(row);
    context.push(point);
    if (context.length > 16) context.shift();
  }
  if (inserted.length > 0) {
    broadcastTelemetry({
      type: "telemetry_ingested",
      count: inserted.length,
      sourceLabel,
      telemetry: serializeTelemetry(inserted.at(-1)!),
    });
    const mostAnomalous = inserted.reduce((highest, row) =>
      row.anomalyScore > highest.anomalyScore ? row : highest,
    );
    await correlateAndCreateIncident(serializeTelemetry(mostAnomalous));
  }
  res.status(201).json(
    IngestTelemetryResponse.parse({
      accepted: true,
      count: inserted.length,
      message: `${inserted.length} telemetry sample${inserted.length === 1 ? "" : "s"} validated and stored as ${sourceLabel}.`,
    }),
  );
});

router.get("/events", async (_req, res): Promise<void> => {
  const rows = await db
    .select()
    .from(missionEventsTable)
    .orderBy(desc(missionEventsTable.occurredAt))
    .limit(200);
  res.json(GetEventsResponse.parse(rows.map(serializeEvent)));
});

router.post("/events/ingest", async (req, res): Promise<void> => {
  const body = IngestEventBody.safeParse(req.body);
  if (!body.success) {
    res.status(400).json({ error: body.error.message });
    return;
  }
  const [row] = await db
    .insert(missionEventsTable)
    .values({ ...body.data, occurredAt: new Date(body.data.occurredAt) })
    .onConflictDoNothing()
    .returning();
  if (!row) {
    res.status(409).json({ error: "An event with this identifier already exists." });
    return;
  }
  broadcastTelemetry({ type: "event_ingested", event: serializeEvent(row) });
  res.status(201).json(IngestEventResponse.parse(serializeEvent(row)));
});

router.get("/incidents", async (_req, res): Promise<void> => {
  const rows = await db.select().from(incidentsTable).orderBy(desc(incidentsTable.updatedAt));
  res.json(GetIncidentsResponse.parse(rows.map(serializeIncident)));
});

router.get("/incidents/:incident_id", async (req, res): Promise<void> => {
  const params = GetIncidentParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  const incident = await getIncidentRecord(params.data.incident_id);
  if (!incident) {
    res.status(404).json({ error: "Incident not found." });
    return;
  }
  const windowStart = new Date(incident.openedAt.getTime() - 2 * 60_000);
  const windowEnd = new Date(incident.updatedAt.getTime() + 2 * 60_000);
  const [events, telemetry] = await Promise.all([
    db
      .select()
      .from(missionEventsTable)
      .orderBy(asc(missionEventsTable.occurredAt))
      .limit(200),
    db
      .select()
      .from(telemetryTable)
      .orderBy(asc(telemetryTable.timestamp))
      .limit(1000),
  ]);
  const incidentTelemetry = telemetry
    .filter((point) => point.timestamp >= windowStart && point.timestamp <= windowEnd)
    .slice(-120);
  const timelineTelemetry = incidentTelemetry
    .filter((point, index) => index % 8 === 0 || point.anomalyStatus !== "NOMINAL")
    .slice(-45);
  const timeline = [
    ...events
      .filter((event) => event.occurredAt >= windowStart && event.occurredAt <= windowEnd)
      .map((event) => ({
        id: event.id,
        kind: "EVENT",
        description: event.description,
        occurredAt: event.occurredAt.toISOString(),
        sourceId: event.id,
      })),
    ...timelineTelemetry
      .map((point) => ({
        id: point.id,
        kind: point.anomalyStatus === "NOMINAL" ? "TELEMETRY" : point.anomalyStatus,
        description: `Battery ${point.batteryVoltage.toFixed(2)} V · anomaly ${point.anomalyScore.toFixed(2)}`,
        occurredAt: point.timestamp.toISOString(),
        sourceId: point.id,
      })),
    {
      id: `TL-${incident.id}`,
      kind: "INCIDENT",
      description: incident.title,
      occurredAt: incident.openedAt.toISOString(),
      sourceId: incident.id,
    },
  ].sort((left, right) => left.occurredAt.localeCompare(right.occurredAt));
  const response = {
    incident: serializeIncident(incident),
    timeline,
    telemetry: incidentTelemetry.map(serializeTelemetry),
  };
  res.json(GetIncidentResponse.parse(response));
});

router.get("/evidence/:source_id", async (req, res): Promise<void> => {
  const params = GetEvidenceParams.safeParse({ source_id: req.params.source_id });
  if (!params.success) {
    res.status(400).json({ error: "Invalid evidence identifier." });
    return;
  }
  const source = await getEvidenceById(params.data.source_id);
  if (!source) {
    res.status(404).json({ error: "Evidence source not found." });
    return;
  }
  res.json(GetEvidenceResponse.parse(source));
});

router.get("/audit", async (_req, res): Promise<void> => {
  const rows = await db.select().from(auditLogsTable).orderBy(desc(auditLogsTable.timestamp)).limit(250);
  res.json(GetAuditResponse.parse(rows.map(serializeAuditRecord)));
});

router.get("/similar-incidents/:incident_id", async (req, res): Promise<void> => {
  const params = GetSimilarIncidentsParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  const incident = await getIncidentRecord(params.data.incident_id);
  if (!incident) {
    res.status(404).json({ error: "Incident not found." });
    return;
  }
  const records = await db.select().from(incidentsTable).orderBy(desc(incidentsTable.openedAt));
  const comparisons = records.filter((candidate) => candidate.id !== incident.id);
  const scores = hybridScores(
    `${incident.title} ${incident.summary}`,
    comparisons.map((candidate) => ({
      content: `${candidate.title} ${candidate.summary}`,
    })),
  );
  const currentTokens = new Set(
    tokenize(`${incident.title} ${incident.summary}`).filter((token) =>
      ["battery", "voltage", "power", "configuration", "communication", "signal", "attitude", "thermal", "wheel", "load"].includes(token),
    ),
  );
  const similar = comparisons
    .map((candidate, index) => {
      const candidateTokens = new Set(
        tokenize(`${candidate.title} ${candidate.summary}`).filter((token) =>
          ["battery", "voltage", "power", "configuration", "communication", "signal", "attitude", "thermal", "wheel", "load"].includes(token),
        ),
      );
      const shared = [...currentTokens].filter((token) => candidateTokens.has(token));
      const similarity = Math.max(0, Math.min(1, scores[index] ?? 0));
      return {
        incident: serializeIncident(candidate),
        similarity: Number(similarity.toFixed(3)),
        rationale: shared.length
          ? [`Shared terms: ${shared.join(", ")}`, "Compared incident title and operator summary."]
          : ["No strong shared subsystem or telemetry terms were identified."],
      };
    })
    .filter((candidate) => candidate.similarity >= 0.05 && candidate.rationale[0] !== "No strong shared subsystem or telemetry terms were identified.")
    .sort((left, right) => right.similarity - left.similarity)
    .slice(0, 5);
  res.json(GetSimilarIncidentsResponse.parse(similar));
});

router.post("/contact", async (req, res): Promise<void> => {
  const body = SubmitContactBody.safeParse(req.body);
  if (!body.success) {
    res.status(400).json({ error: body.error.message });
    return;
  }
  const clean = (text: string) => text.replace(/[\u0000-\u0008\u000B\u000C\u000E-\u001F\u007F]/g, "").trim();
  const [saved] = await db
    .insert(contactMessagesTable)
    .values({
      id: `MSG-${randomUUID().slice(0, 10).toUpperCase()}`,
      name: clean(body.data.name),
      email: clean(body.data.email),
      organization: clean(body.data.organization ?? ""),
      message: clean(body.data.message),
    })
    .returning({ id: contactMessagesTable.id });
  const result = { success: Boolean(saved), message: "Message received." };
  res.status(201).json(SubmitContactResponse.parse(result));
});

export default router;
