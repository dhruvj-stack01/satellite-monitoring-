import { Router, type IRouter } from "express";
import {
  GetSimulationStatusResponse,
  ReplayIncidentResponse,
  StartSimulationResponse,
  StopSimulationResponse,
} from "@workspace/api-zod";
import {
  getSimulationStatus,
  replayCriticalIncident,
  startSimulation,
  stopSimulation,
} from "../lib/simulation";

const router: IRouter = Router();

router.post("/simulation/start", (_req, res): void => {
  res.json(StartSimulationResponse.parse(startSimulation()));
});

router.post("/simulation/stop", (_req, res): void => {
  res.json(StopSimulationResponse.parse(stopSimulation()));
});

router.get("/simulation/status", (_req, res): void => {
  res.json(GetSimulationStatusResponse.parse(getSimulationStatus()));
});

router.post("/simulation/replay-incident", (_req, res): void => {
  res.json(ReplayIncidentResponse.parse(replayCriticalIncident()));
});

export default router;
