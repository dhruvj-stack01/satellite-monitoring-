import { type FormEvent, type ReactNode, useEffect, useState } from 'react';
import { QueryClient, QueryClientProvider, useQueryClient } from '@tanstack/react-query';
import { ErrorBoundary } from '@/components/error-boundary';
import { Toaster } from '@/components/ui/toaster';
import { TooltipProvider } from '@/components/ui/tooltip';
import { Link, Route, Switch, Router as WouterRouter, useLocation, useParams } from 'wouter';
import {
  Activity, AlertTriangle, ArrowRight, ArrowUpRight, BookOpen, Check, ChevronDown, CircleHelp,
  Command, Database, FileClock, FileSearch, Gauge, Globe2, Layers3, Menu, Orbit, Radio,
  RefreshCw, Search, Shield, ShieldCheck, Signal, Sparkles, Upload, X,
} from 'lucide-react';
import {
  useHealthCheck, useGetDashboard, useGetSpacecraft, useGetLatestTelemetry, useGetTelemetryHistory,
  useIngestTelemetry, useGetEvents, useIngestEvent, useGetIncidents, useGetIncident,
  useInvestigateIncident, useInvestigate, useSearchEvidence, useGetEvidence, useGetAudit,
  useGetSimilarIncidents, useStartSimulation, useStopSimulation, useGetSimulationStatus,
  useReplayIncident, useSubmitContact, getGetDashboardQueryKey, getGetLatestTelemetryQueryKey,
  getGetTelemetryHistoryQueryKey, getGetIncidentQueryKey, getGetEventsQueryKey,
  getGetAuditQueryKey, getGetSimulationStatusQueryKey, getGetEvidenceQueryKey,
  getGetSimilarIncidentsQueryKey,
} from '@workspace/api-client-react';
import type { EvidenceSource, EventInput, Investigation, TelemetryInputItem, TelemetryRecord } from '@workspace/api-client-react';

const queryClient = new QueryClient({ defaultOptions: { queries: { staleTime: 12_000, retry: 1 } } });

const navSections = [
  { label: 'MISSION', items: [{ title: 'Overview', path: '/', icon: Orbit }, { title: 'Live dashboard', path: '/dashboard', icon: Gauge }, { title: 'Telemetry stream', path: '/telemetry', icon: Activity }, { title: 'Incidents', path: '/incidents', icon: AlertTriangle }] },
  { label: 'INTELLIGENCE', items: [{ title: 'Copilot', path: '/copilot', icon: Sparkles }, { title: 'Evidence library', path: '/evidence', icon: FileSearch }, { title: 'Audit trail', path: '/audit', icon: FileClock }] },
  { label: 'OPERATIONS', items: [{ title: 'Safety guardrails', path: '/safety', icon: ShieldCheck }, { title: 'System flow', path: '/architecture', icon: Layers3 }, { title: 'Ingestion', path: '/ingestion', icon: Upload }] },
];

function when(value?: string | null) {
  if (!value) return '—';
  const date = new Date(value);
  return Number.isNaN(date.getTime()) ? value : date.toLocaleString(undefined, { month: 'short', day: '2-digit', hour: '2-digit', minute: '2-digit', second: '2-digit', hour12: false });
}
function shortWhen(value?: string | null) {
  if (!value) return '—';
  const date = new Date(value);
  return Number.isNaN(date.getTime()) ? value : date.toLocaleTimeString(undefined, { hour: '2-digit', minute: '2-digit', second: '2-digit', hour12: false });
}
function titleCase(value?: string) { return (value || 'unknown').toLowerCase().replaceAll('_', ' ').replace(/\b\w/g, (letter) => letter.toUpperCase()); }
function errText(error: unknown) { return error instanceof Error ? error.message : 'Request could not be completed.'; }

function LoadState({ error, loading, empty, retry }: { error?: unknown; loading?: boolean; empty?: boolean; retry?: () => void }) {
  if (loading) return <div className="load-state" aria-live="polite"><span className="skeleton-line" /><span className="skeleton-line short" /><span className="skeleton-line" /></div>;
  if (error) return <div className="state-box error-box"><AlertTriangle size={17} /><div><b>Data unavailable</b><p>{errText(error)}</p>{retry && <button className="text-action" onClick={retry} data-testid="button-retry">Retry request <RefreshCw size={13} /></button>}</div></div>;
  if (empty) return <div className="state-box"><Database size={18} /><div><b>No records returned</b><p>There is no backend data in this view yet.</p></div></div>;
  return null;
}

function Badge({ children, kind = 'neutral' }: { children: ReactNode; kind?: string }) {
  return <span className={`badge badge-${kind.toLowerCase().replaceAll(' ', '-')}`}>{children}</span>;
}
function Panel({ children, className = '' }: { children: ReactNode; className?: string }) { return <section className={`panel panel-pad ${className}`}>{children}</section>; }
function PageHead({ eyebrow, title, description, right }: { eyebrow: string; title: string; description?: string; right?: ReactNode }) {
  return <div className="page-head"><div><div className="eyebrow">{eyebrow}</div><h1 className="display">{title}</h1>{description && <p>{description}</p>}</div>{right && <div className="page-head-right">{right}</div>}</div>;
}
function SectionHead({ title, meta, action }: { title: string; meta?: string; action?: ReactNode }) {
  return <div className="section-head"><div><h2>{title}</h2>{meta && <span className="muted">{meta}</span>}</div>{action}</div>;
}
function Metric({ label, value, unit, note, tone = 'blue', testId }: { label: string; value: ReactNode; unit?: string; note?: string; tone?: string; testId: string }) {
  return <div className={`metric metric-${tone}`} data-testid={testId}><div className="metric-label">{label}</div><div className="metric-value mono">{value}<small>{unit}</small></div>{note && <div className="metric-note">{note}</div>}</div>;
}

function LiveSocket() {
  const qc = useQueryClient();
  const [connected, setConnected] = useState(false);
  useEffect(() => {
    let socket: WebSocket | null = null;
    let stopped = false;
    let timer: number | undefined;
    let retry = 1200;
    const connect = () => {
      if (stopped) return;
      const scheme = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
      socket = new WebSocket(`${scheme}//${window.location.host}/api/ws/telemetry`);
      socket.onopen = () => { retry = 1200; setConnected(true); };
      socket.onmessage = (event) => {
        try {
          const parsed = JSON.parse(event.data) as unknown;
          const candidate = (parsed && typeof parsed === 'object' && 'telemetry' in parsed) ? (parsed as { telemetry: TelemetryRecord }).telemetry : parsed;
          if (candidate && typeof candidate === 'object' && 'batteryVoltage' in candidate) {
            qc.setQueryData(getGetLatestTelemetryQueryKey(), candidate);
            qc.invalidateQueries({ queryKey: getGetDashboardQueryKey() });
          }
        } catch { /* Unrecognized stream frame; refresh below on reconnect. */ }
      };
      socket.onclose = () => {
        if (stopped) return;
        setConnected(false);
        qc.invalidateQueries({ queryKey: getGetLatestTelemetryQueryKey() });
        qc.invalidateQueries({ queryKey: getGetDashboardQueryKey() });
        timer = window.setTimeout(connect, retry);
        retry = Math.min(retry * 1.7, 15000);
      };
      socket.onerror = () => socket?.close();
    };
    connect();
    return () => { stopped = true; window.clearTimeout(timer); socket?.close(); };
  }, [qc]);
  return <span className="socket-status"><i className={connected ? 'signal-dot online' : 'signal-dot'} />{connected ? 'STREAM CONNECTED' : 'STREAM RECONNECTING'}</span>;
}

function Shell({ children }: { children: ReactNode }) {
  const [location] = useLocation();
  const [mobileOpen, setMobileOpen] = useState(false);
  const health = useHealthCheck();
  const sim = useGetSimulationStatus();
  const dashboard = useGetDashboard();
  const queryClientLocal = useQueryClient();
  useEffect(() => { setMobileOpen(false); }, [location]);
  const refresh = () => {
    queryClientLocal.invalidateQueries({ queryKey: getGetDashboardQueryKey() });
    queryClientLocal.invalidateQueries({ queryKey: getGetLatestTelemetryQueryKey() });
    queryClientLocal.invalidateQueries({ queryKey: getGetTelemetryHistoryQueryKey() });
  };
  return <div className="app-shell">
    <aside className={`sidebar ${mobileOpen ? 'sidebar-open' : ''}`}>
      <Link href="/" className="brand-lockup" data-testid="link-brand"><span className="brand-mark"><Orbit size={21} /></span><span><b>MISSION / OPS</b><small>DECISION SUPPORT SYSTEM</small></span></Link>
      <div className="sidebar-rule" />
      <div className="spacecraft-select"><span className="tiny-label">ACTIVE VEHICLE</span><div className="vehicle-row"><span className="vehicle-icon"><Orbit size={15} /></span><span>ORBITAL ASSET</span><ChevronDown size={13} /></div><span className="vehicle-caption">Telemetry scope · all monitored</span></div>
      <nav aria-label="Primary navigation" className="nav-groups">
        {navSections.map((group) => <div className="nav-group" key={group.label}><div className="nav-label">{group.label}</div>{group.items.map(({ title, path, icon: Icon }) => <Link key={path} href={path} className={`nav-link ${location === path || (path === '/incidents' && location.startsWith('/incidents/')) ? 'active' : ''}`} data-testid={`link-nav-${title.toLowerCase().replaceAll(' ', '-')}`}><Icon size={16} strokeWidth={1.8} /><span>{title}</span>{path === '/incidents' && dashboard.data?.activeIncidentCount ? <span className="nav-count" data-testid="status-incidents-count">{dashboard.data.activeIncidentCount}</span> : null}</Link>)}</div>)}
      </nav>
      <div className="sidebar-bottom">
        <div className="health-row"><span className={`health-dot ${health.isError ? 'down' : ''}`} /><span>API {health.isLoading ? 'CHECKING' : health.isError ? 'UNAVAILABLE' : 'OPERATIONAL'}</span></div>
        <div className="safety-reminder"><Shield size={15} /><span>HUMAN AUTHORITY<br /><b>ALWAYS RETAINED</b></span></div>
        <div className="sidebar-version mono">MOC · SIMULATION ENVIRONMENT</div>
      </div>
    </aside>
    {mobileOpen && <button className="mobile-scrim" aria-label="Close navigation" onClick={() => setMobileOpen(false)} data-testid="button-close-menu" />}
    <main className="main-area">
      <header className="topbar">
        <button className="mobile-menu" onClick={() => setMobileOpen((v) => !v)} aria-label="Toggle navigation" data-testid="button-toggle-menu">{mobileOpen ? <X size={19} /> : <Menu size={19} />}</button>
        <div className="crumb"><span>MISSION OPERATIONS</span><span className="slash">/</span><b>{(navSections.flatMap((x) => x.items).find((x) => x.path === location)?.title || (location.startsWith('/incidents/') ? 'Investigation' : 'Mission console')).toUpperCase()}</b></div>
        <div className="topbar-right"><LiveSocket /><Badge kind="warning">SIMULATED LIVE TELEMETRY</Badge><span className="no-live"><i />NO LIVE SPACECRAFT CONNECTION</span><button className="icon-btn refresh-btn" onClick={refresh} aria-label="Refresh mission data" data-testid="button-refresh"><RefreshCw size={15} /></button></div>
      </header>
      <div className="mobile-signal"><span className="mobile-live-warning">NO LIVE SPACECRAFT CONNECTION</span><span className="mobile-live-warning">DECISION SUPPORT ONLY</span></div>
      <div className="work-area">{children}</div>
      <footer className="app-footer"><span>MISSION OPERATIONS COPILOT</span><span>SIMULATED / HISTORICAL / OPERATOR-UPLOADED DATA · NO COMMAND AUTHORITY</span><span className="mono">v0.1</span></footer>
    </main>
  </div>;
}

function Home() {
  const q = useGetDashboard();
  const dashboard = q.data;
  const [contactStatus, setContactStatus] = useState('');
  const contact = useSubmitContact();
  const refresh = () => q.refetch();
  const submitContact = (e: FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const f = new FormData(e.currentTarget);
    contact.mutate({ data: { name: String(f.get('name')), email: String(f.get('email')), organization: String(f.get('organization') || ''), message: String(f.get('message')) } }, {
      onSuccess: (result) => setContactStatus(result.message),
      onError: (error) => setContactStatus(errText(error)),
    });
  };
  return <div className="page-wrap enter">
    <div className="hero-overview">
      <div className="hero-copy">
        <div className="eyebrow"><span className="eyebrow-line" />MISSION DECISION SUPPORT <span className="mono">/ 01</span></div>
        <h1 className="display">Make the signal<br /><em>traceable.</em></h1>
        <p className="hero-description">A clear line from spacecraft telemetry to operator decision. Correlate simulated health signals, anomaly context, procedures and incident history—without surrendering human authority.</p>
        <div className="hero-actions"><Link href="/dashboard" className="button-primary" data-testid="link-open-dashboard">Open mission dashboard <ArrowRight size={16} /></Link><Link href="/copilot" className="button-quiet" data-testid="link-ask-copilot">Ask the copilot <Command size={15} /></Link></div>
      </div>
      <div className="hero-visual grid-bg">
        <div className="visual-top"><span>TRACKING FRAME // 001</span><span className="mono">SIMULATION</span></div>
        <div className="orbital-graphic"><div className="orbit orbit-a" /><div className="orbit orbit-b" /><div className="orbit orbit-c" /><div className="planet"><Orbit size={31} strokeWidth={1.1} /></div><span className="orbit-node node-a" /><span className="orbit-node node-b" /></div>
        <div className="visual-coordinates"><span>POSITIONAL MODEL</span><span className="mono">STATE: {dashboard?.spacecraft.status ?? 'AWAITING DATA'}</span></div>
        <div className="visual-caption">ANALYTIC VIEW · NOT A COMMAND LINK</div>
      </div>
    </div>
        <div className="data-provenance"><div className="provenance-mark"><Radio size={16} /></div><div><b>SIMULATED LIVE TELEMETRY</b><span>State and values are generated for decision-support evaluation.</span></div><div className="provenance-divider" /><div className="provenance-mark historical"><Globe2 size={16} /></div><div><b>HISTORICAL DEMO DATA</b><span>Fictional reference incidents, not public mission records.</span></div><div className="connection-warning"><span className="warning-square">!</span>NO LIVE SPACECRAFT CONNECTION</div></div>
    <div className="home-grid">
      <Panel className="home-state">
        <SectionHead title="Current mission state" meta="Backend-reported snapshot" />
        <LoadState loading={q.isLoading} error={q.error} empty={!dashboard && !q.isLoading && !q.isError} retry={refresh} />
        {dashboard && <><div className="asset-title"><div className="asset-orbit"><Orbit size={19} /></div><div><h3>{dashboard.spacecraft.name}</h3><span className="mono">{dashboard.spacecraft.id} · {dashboard.spacecraft.sourceLabel}</span></div><Badge kind={dashboard.spacecraft.status}>{titleCase(dashboard.spacecraft.status)}</Badge></div>
          <div className="mini-metrics"><Metric label="Battery voltage" value={dashboard.latestTelemetry.batteryVoltage.toFixed(2)} unit="V" testId="value-home-battery" /><Metric label="Solar power" value={dashboard.latestTelemetry.solarPower.toFixed(1)} unit="W" testId="value-home-solar" /><Metric label="Anomaly score" value={dashboard.latestTelemetry.anomalyScore.toFixed(2)} tone={dashboard.latestTelemetry.anomalyStatus === 'NOMINAL' ? 'blue' : 'red'} testId="value-home-anomaly" /></div>
          <div className="state-bottom"><span>LAST CONTACT <b className="mono">{when(dashboard.spacecraft.lastContactAt)}</b></span><Link href="/dashboard" className="text-action" data-testid="link-state-detail">View live state <ArrowRight size={13} /></Link></div></>}
      </Panel>
      <Panel className="home-rail">
        <div className="rail-top"><div className="rail-icon"><ShieldCheck size={17} /></div><Badge kind="success">HUMAN IN THE LOOP</Badge></div>
        <h3>Evidence before advice.</h3><p>Facts, hypotheses, and recommendations stay distinct. Every investigation links back to retrieved source material and a recorded audit entry.</p>
        <div className="rail-rows"><div><span>Command issued</span><b>NONE</b></div><div><span>Authority</span><b>OPERATOR</b></div><div><span>Live connection</span><b>NOT CONNECTED</b></div></div>
        <Link className="rail-link" href="/safety" data-testid="link-safety-overview">Read safety guardrails <ArrowRight size={14} /></Link>
      </Panel>
    </div>
    <div className="home-lower">
      <Panel><SectionHead title="Operational picture" meta="Latest returned by mission API" /><LoadState loading={q.isLoading} error={q.error} empty={!dashboard?.recentEvents?.length && !q.isLoading && !q.isError} />{dashboard?.recentEvents?.length ? <div className="event-list">{dashboard.recentEvents.slice(0, 4).map((event) => <EventRow key={event.id} event={event} />)}</div> : null}</Panel>
      <Panel className="home-actions"><div className="eyebrow">OPERATOR WORKSPACE</div><h3>Where would you like to begin?</h3><div className="action-links"><Link href="/telemetry" data-testid="link-review-telemetry"><Activity size={16} /><span>Inspect telemetry stream</span><ArrowRight size={14} /></Link><Link href="/incidents" data-testid="link-review-incidents"><AlertTriangle size={16} /><span>Review incidents</span><ArrowRight size={14} /></Link><Link href="/evidence" data-testid="link-review-evidence"><BookOpen size={16} /><span>Explore evidence sources</span><ArrowRight size={14} /></Link></div></Panel>
    </div>
    <Panel className="contact-panel"><div><div className="eyebrow">MISSION SUPPORT</div><h3>Questions about the evaluation environment?</h3><p>Send a note to the mission support team.</p></div><form className="contact-form" onSubmit={submitContact}><input name="name" placeholder="Name" aria-label="Name" required data-testid="input-contact-name" /><input name="email" placeholder="Email" type="email" aria-label="Email" required data-testid="input-contact-email" /><input name="organization" placeholder="Organization (optional)" aria-label="Organization" data-testid="input-contact-organization" /><textarea name="message" placeholder="Message" aria-label="Message" required data-testid="input-contact-message" /><button className="button-primary" disabled={contact.isPending} data-testid="button-submit-contact">{contact.isPending ? 'Sending…' : 'Send message'} <ArrowRight size={14} /></button>{contactStatus && <span className="form-note" role="status">{contactStatus}</span>}</form></Panel>
  </div>;
}

function EventRow({ event }: { event: { id: string; eventType: string; subsystem: string; description: string; occurredAt: string; severity: string; sourceLabel: string } }) {
  return <div className="event-row" data-testid={`row-event-${event.id}`}><span className={`severity-marker ${event.severity.toLowerCase()}`} /><div className="event-main"><div><b>{titleCase(event.eventType)}</b><span className="muted"> / {event.subsystem}</span></div><p>{event.description}</p><span className="event-source">{event.sourceLabel}</span></div><span className="event-time mono">{shortWhen(event.occurredAt)}</span><Badge kind={event.severity}>{event.severity}</Badge></div>;
}

function Dashboard() {
  const qc = useQueryClient();
  const q = useGetDashboard({ query: { refetchInterval: 20_000, queryKey: getGetDashboardQueryKey() } });
  const sim = useGetSimulationStatus({ query: { refetchInterval: 10_000, queryKey: getGetSimulationStatusQueryKey() } });
  const start = useStartSimulation();
  const stop = useStopSimulation();
  const dashboard = q.data;
  const changeSimulation = () => {
    const mutation = sim.data?.running ? stop : start;
    mutation.mutate(undefined, { onSuccess: () => {
      qc.invalidateQueries({ queryKey: getGetSimulationStatusQueryKey() });
      qc.invalidateQueries({ queryKey: getGetDashboardQueryKey() });
      qc.invalidateQueries({ queryKey: getGetLatestTelemetryQueryKey() });
    } });
  };
  const record = dashboard?.latestTelemetry;
  return <div className="page-wrap enter">
    <PageHead eyebrow="MISSION CONTROL / LIVE STATE" title="Mission dashboard" description="A live view of the simulated mission stream and current spacecraft health." right={<button className="button-outline" onClick={changeSimulation} disabled={start.isPending || stop.isPending} data-testid="button-simulation-toggle">{sim.data?.running ? 'Pause simulation' : 'Start simulation'} <ArrowRight size={14} /></button>} />
    <div className="source-banners"><div className="source-banner simulated"><span className="pulse-dot" /><div><b>SIMULATED LIVE TELEMETRY</b><small>Generated stream · values are not from an operational vehicle</small></div></div><div className="source-banner no-connection"><Signal size={16} /><div><b>NO LIVE SPACECRAFT CONNECTION</b><small>Decision-support only · no command path available</small></div></div></div>
    <LoadState loading={q.isLoading} error={q.error} empty={!dashboard && !q.isLoading && !q.isError} retry={() => q.refetch()} />
    {dashboard && <><div className="dashboard-asset panel"><div className="asset-orbit"><Orbit size={21} /></div><div className="dashboard-asset-main"><span className="tiny-label">MONITORED SPACECRAFT</span><h2 className="display">{dashboard.spacecraft.name}</h2><span className="mono">{dashboard.spacecraft.id} · SOURCE {dashboard.spacecraft.sourceLabel}</span></div><div className="asset-contact"><span className="tiny-label">LAST CONTACT</span><b className="mono">{when(dashboard.spacecraft.lastContactAt)}</b></div><Badge kind={dashboard.spacecraft.status}>{titleCase(dashboard.spacecraft.status)}</Badge></div>
      {record && <div className="metric-grid">
        <Metric label="Battery voltage" value={record.batteryVoltage.toFixed(2)} unit="V" note="BUS / POWER" testId="value-live-battery" />
        <Metric label="Solar array" value={record.solarPower.toFixed(1)} unit="W" note="GENERATION" testId="value-live-solar" />
        <Metric label="Battery temperature" value={record.batteryTemperature.toFixed(1)} unit="°C" note="THERMAL" testId="value-live-temperature" />
        <Metric label="Comm. signal" value={record.communicationSignal.toFixed(1)} unit="dBm" note="RF LINK" testId="value-live-signal" />
        <Metric label="Attitude error" value={record.attitudeError.toFixed(3)} unit="°" note="GUIDANCE" testId="value-live-attitude" />
        <Metric label="Anomaly score" value={record.anomalyScore.toFixed(2)} unit="" note={titleCase(record.anomalyStatus)} tone={record.anomalyStatus === 'NOMINAL' ? 'blue' : 'red'} testId="value-live-anomaly" />
      </div>}
      <div className="dashboard-columns"><TelemetryTrend /><Panel><SectionHead title="Mission activity" meta={`${dashboard.recentEvents.length} returned events`} /><div className="event-list compact">{dashboard.recentEvents.length ? dashboard.recentEvents.slice(0, 5).map((event) => <EventRow key={event.id} event={event} />) : <div className="empty-inline">No mission events returned.</div>}</div><Link className="text-action more-link" href="/incidents" data-testid="link-dashboard-incidents">Open incident register <ArrowRight size={13} /></Link></Panel></div>
    </>}
    <div className="live-footnote"><span>STREAM STATUS IS SHOWN IN THE HEADER</span><span>Snapshot timestamp <b className="mono">{record ? when(record.timestamp) : '—'}</b></span><span className="separator">·</span><span>Simulation {sim.isLoading ? 'status checking' : sim.data?.running ? 'running' : 'stopped'}</span></div>
  </div>;
}

function TelemetryTrend() {
  const q = useGetTelemetryHistory({ limit: 60 }, { query: { queryKey: getGetTelemetryHistoryQueryKey({ limit: 60 }), refetchInterval: 30_000 } });
  const history = q.data || [];
  const values = history.slice().reverse();
  const voltageValues = values.map((row) => row.batteryVoltage);
  const minVoltage = voltageValues.length ? Math.min(...voltageValues) : 0;
  const maxVoltage = voltageValues.length ? Math.max(...voltageValues) : 0;
  const line = (key: keyof TelemetryRecord, width = 660, height = 154) => {
    if (!values.length) return '';
    const nums = values.map((x) => Number(x[key])).filter(Number.isFinite);
    const min = Math.min(...nums); const range = Math.max(...nums) - min || 1;
    return nums.map((value, index) => `${index === 0 ? 'M' : 'L'} ${(index / Math.max(nums.length - 1, 1) * width).toFixed(1)} ${(height - 8 - (value - min) / range * (height - 18)).toFixed(1)}`).join(' ');
  };
  return <Panel className="trend-panel"><SectionHead title="Telemetry trace" meta="Battery voltage · V" action={<Link className="text-action" href="/telemetry" data-testid="link-full-telemetry">Full stream <ArrowRight size={13} /></Link>} />
    <LoadState loading={q.isLoading} error={q.error} empty={!history.length && !q.isLoading && !q.isError} retry={() => q.refetch()} />
    {history.length > 0 && <div className="chart-shell"><div className="chart-axis">{[1, 2 / 3, 1 / 3, 0].map((fraction) => <span key={fraction}>{(minVoltage + (maxVoltage - minVoltage) * fraction).toFixed(1)}</span>)}</div><svg viewBox="0 0 660 154" role="img" aria-label="Backend battery voltage history chart" preserveAspectRatio="none"><defs><linearGradient id="trace-fill" x1="0" x2="0" y1="0" y2="1"><stop offset="0" stopColor="#40bde7" stopOpacity=".2" /><stop offset="1" stopColor="#40bde7" stopOpacity="0" /></linearGradient></defs><path d={`${line('batteryVoltage')} L 660 154 L 0 154 Z`} fill="url(#trace-fill)" /><path d={line('batteryVoltage')} className="chart-line" /></svg><div className="chart-labels"><span>{shortWhen(values[0]?.timestamp)}</span><span>{shortWhen(values[Math.floor(values.length / 2)]?.timestamp)}</span><span>{shortWhen(values.at(-1)?.timestamp)}</span></div></div>}
    <div className="chart-footer"><span><i className="legend-dot" />BATTERY VOLTAGE</span><span className="mono">{history.length} samples · backend history</span></div>
  </Panel>;
}

function Telemetry() {
  const history = useGetTelemetryHistory({ limit: 250 }, { query: { queryKey: getGetTelemetryHistoryQueryKey({ limit: 250 }) } });
  const spacecraft = useGetSpacecraft();
  const latest = useGetLatestTelemetry({ query: { queryKey: getGetLatestTelemetryQueryKey(), refetchInterval: 15000 } });
  const items = history.data || [];
  return <div className="page-wrap enter">
    <PageHead eyebrow="MISSION DATA / TELEMETRY" title="Telemetry stream" description="Backend telemetry records with their source labels intact." right={<Badge kind="warning">SIMULATED / HISTORICAL</Badge>} />
    <div className="source-banners compact-banners"><div className="source-banner simulated"><Radio size={16} /><div><b>SIMULATED LIVE TELEMETRY</b><small>Can be generated by the simulation service</small></div></div><div className="source-banner historical"><Globe2 size={16} /><div><b>HISTORICAL DEMO DATA</b><small>Fictional reference records; not public mission data</small></div></div><div className="source-banner no-connection"><span className="warning-square">!</span><div><b>NO LIVE SPACECRAFT CONNECTION</b></div></div></div>
    <div className="stat-strip"><Metric label="Latest battery" value={latest.data?.batteryVoltage.toFixed(2) ?? '—'} unit="V" testId="value-telemetry-latest" /><Metric label="Records loaded" value={items.length} note="REQUEST LIMIT 250" testId="value-telemetry-count" /><Metric label="Spacecraft monitored" value={spacecraft.data?.length ?? '—'} testId="value-spacecraft-count" /><Metric label="Latest sample" value={latest.data ? shortWhen(latest.data.timestamp) : '—'} testId="value-telemetry-timestamp" /></div>
    <Panel><SectionHead title="Recent samples" meta="Most recent records from telemetry history" /><LoadState loading={history.isLoading} error={history.error} empty={!items.length && !history.isLoading && !history.isError} retry={() => history.refetch()} />
      {items.length > 0 && <div className="table-scroll"><table><thead><tr><th>Timestamp</th><th>Spacecraft</th><th>Battery V</th><th>Solar W</th><th>Temp °C</th><th>Signal dBm</th><th>Attitude °</th><th>Anomaly</th><th>Source</th></tr></thead><tbody>{items.map((row) => <tr key={row.id} data-testid={`row-telemetry-${row.id}`}><td className="mono">{when(row.timestamp)}</td><td className="mono">{row.spacecraftId}</td><td className="mono">{row.batteryVoltage.toFixed(2)}</td><td className="mono">{row.solarPower.toFixed(1)}</td><td className="mono">{row.batteryTemperature.toFixed(1)}</td><td className="mono">{row.communicationSignal.toFixed(1)}</td><td className="mono">{row.attitudeError.toFixed(3)}</td><td><Badge kind={row.anomalyStatus}>{titleCase(row.anomalyStatus)}</Badge></td><td><span className="source-label">{row.sourceLabel}</span></td></tr>)}</tbody></table></div>}
    </Panel>
    <Panel className="spacecraft-panel"><SectionHead title="Monitored spacecraft" meta="Backend registry" /><LoadState loading={spacecraft.isLoading} error={spacecraft.error} empty={!spacecraft.data?.length && !spacecraft.isLoading && !spacecraft.isError} retry={() => spacecraft.refetch()} />{spacecraft.data?.map((ship) => <div className="spacecraft-row" key={ship.id} data-testid={`row-spacecraft-${ship.id}`}><Orbit size={16} /><b>{ship.name}</b><span className="mono">{ship.id}</span><Badge kind={ship.status}>{titleCase(ship.status)}</Badge><span className="source-label">{ship.sourceLabel}</span><span className="muted">Contact {when(ship.lastContactAt)}</span></div>)}</Panel>
  </div>;
}

function Incidents() {
  const q = useGetIncidents();
  const events = useGetEvents();
  const incidents = q.data || [];
  return <div className="page-wrap enter">
    <PageHead eyebrow="MISSION RECORD / ANOMALY CONTEXT" title="Incident register" description="Active and historical incidents returned by the mission service." right={<Badge kind="neutral">{incidents.length} RECORDS</Badge>} />
    <div className="incident-summary"><div><AlertTriangle size={16} /><span>Evidence-led investigations keep observed data separate from possible explanations.</span></div><Link className="button-outline" href="/copilot" data-testid="link-investigate-question">Open copilot <ArrowRight size={14} /></Link></div>
    <Panel><SectionHead title="Incidents" meta="Select a record to inspect its context and sources" /><LoadState loading={q.isLoading} error={q.error} empty={!incidents.length && !q.isLoading && !q.isError} retry={() => q.refetch()} />
      <div className="incident-cards">{incidents.map((item) => <Link href={`/incidents/${item.id}`} className="incident-card" key={item.id} data-testid={`link-incident-${item.id}`}><div className={`incident-severity ${item.severity.toLowerCase()}`}><AlertTriangle size={17} /></div><div className="incident-details"><div className="incident-title-line"><h3>{item.title}</h3><Badge kind={item.severity}>{item.severity}</Badge><Badge kind={item.status}>{titleCase(item.status)}</Badge></div><p>{item.summary}</p><div className="incident-meta"><span>OPENED <b className="mono">{when(item.openedAt)}</b></span><span>UPDATED <b className="mono">{when(item.updatedAt)}</b></span><span className="mono">REF {item.id}</span></div></div><ArrowRight className="incident-arrow" size={17} /></Link>)}</div>
    </Panel>
    <Panel><SectionHead title="Recent mission events" meta="Contextual event records" /><LoadState loading={events.isLoading} error={events.error} empty={!events.data?.length && !events.isLoading && !events.isError} retry={() => events.refetch()} /><div className="event-list">{events.data?.map((event) => <EventRow event={event} key={event.id} />)}</div></Panel>
  </div>;
}

function Claim({ label, claim, tone }: { label: string; claim?: { text: string; validation: string; sourceIds: string[] }; tone?: string }) {
  if (!claim) return null;
  return <div className={`claim claim-${tone || 'fact'}`}><div className="claim-label"><span>{label}</span><Badge kind={claim.validation}>{titleCase(claim.validation)}</Badge></div><p>{claim.text}</p>{claim.sourceIds?.length > 0 && <div className="claim-sources">{claim.sourceIds.map((id) => <Link href={`/evidence?source=${encodeURIComponent(id)}`} key={id} data-testid={`link-claim-source-${id}`}>SOURCE {id} <ArrowUpRight size={11} /></Link>)}</div>}</div>;
}
function InvestigationResult({ data }: { data: Investigation }) {
  return <div className="investigation-result enter"><div className="investigation-top"><div><div className="eyebrow">INVESTIGATION RESULT <span className="mono">/ {data.aiMode}</span></div><h2 className="display">Evidence review</h2></div><Badge kind={data.evidenceSufficiency}>{titleCase(data.evidenceSufficiency)} evidence</Badge></div>
    <Claim label="Observed facts" claim={data.observedFacts?.[0]} tone="fact" />
    {data.observedFacts?.slice(1).map((claim, i) => <Claim key={i} label="Observed fact" claim={claim} tone="fact" />)}
    {data.correlatedEvents?.map((claim, i) => <Claim key={i} label="Correlated event" claim={claim} tone="fact" />)}
    {data.historicalContext?.map((claim, i) => <Claim key={i} label="Historical context" claim={claim} tone="fact" />)}
    <Claim label="Hypothesis · not a confirmed cause" claim={data.hypothesis} tone="hypothesis" />
    <Claim label="Recommendation · operator review required" claim={data.recommendation} tone="recommendation" />
    {data.missingEvidence?.length > 0 && <div className="missing-box"><div><CircleHelp size={15} />INSUFFICIENT OR MISSING EVIDENCE</div><ul>{data.missingEvidence.map((m, i) => <li key={i}>{m}</li>)}</ul></div>}
    <div className="result-meta"><span>CONFIDENCE <b className="mono">{(data.confidence * 100).toFixed(1)}%</b></span><span>SUFFICIENCY <b>{titleCase(data.evidenceSufficiency)}</b></span><span>COMMAND ISSUED <b>{data.commandIssued}</b></span><span>AUDIT <Link href="/audit" className="mono">{data.auditId}</Link></span></div>
    <SourceList sources={data.sources || []} />
  </div>;
}
function SourceList({ sources }: { sources: EvidenceSource[] }) {
  if (!sources.length) return <div className="empty-inline">No supporting sources were returned.</div>;
  return <div className="result-sources"><div className="eyebrow">RETRIEVED EVIDENCE <span className="mono">/ {sources.length}</span></div>{sources.map((source) => <div className="source-item" key={source.sourceId} data-testid={`source-item-${source.sourceId}`}><div className="source-type">{titleCase(source.sourceType)}</div><div className="source-copy"><b>{source.title}</b><p>{source.content}</p><span>{source.relevance}</span></div><div className="source-score mono">{(source.score * 100).toFixed(0)}<small>%</small></div></div>)}</div>;
}

function IncidentInvestigation() {
  const { incidentId } = useParams<{ incidentId: string }>();
  const id = incidentId || '';
  const q = useGetIncident(id, { query: { enabled: !!id, queryKey: getGetIncidentQueryKey(id) } });
  const similar = useGetSimilarIncidents(id, { query: { enabled: !!id, queryKey: getGetSimilarIncidentsQueryKey(id) } });
  const investigate = useInvestigateIncident();
  const replay = useReplayIncident();
  const [result, setResult] = useState<Investigation | null>(null);
  const [question, setQuestion] = useState('');
  const incident = q.data?.incident;
  const run = (e: FormEvent) => {
    e.preventDefault();
    if (!incident) return;
    investigate.mutate({ incidentId: id, data: { question: question.trim() || `Summarize the evidence and possible causes for ${incident.title}.`, incidentId: id } }, { onSuccess: (data) => { setResult(data); queryClient.invalidateQueries({ queryKey: getGetAuditQueryKey() }); } });
  };
  return <div className="page-wrap enter">
    <PageHead eyebrow="INCIDENT REVIEW / EVIDENCE RETRIEVAL" title={incident?.title || 'Incident investigation'} description={incident?.summary || 'Review the backend incident record and request a source-grounded investigation.'} right={<Link href="/incidents" className="button-outline" data-testid="link-back-incidents">Incident register <ArrowRight size={14} /></Link>} />
    <LoadState loading={q.isLoading} error={q.error} empty={!q.data && !q.isLoading && !q.isError} retry={() => q.refetch()} />
    {incident && <><div className="incident-summary"><div><Badge kind={incident.severity}>{incident.severity}</Badge><Badge kind={incident.status}>{titleCase(incident.status)}</Badge><span>Opened <b className="mono">{when(incident.openedAt)}</b></span><span>Updated <b className="mono">{when(incident.updatedAt)}</b></span></div><button className="button-outline" onClick={() => replay.mutate(undefined)} disabled={replay.isPending} data-testid="button-replay-incident">{replay.isPending ? 'Requesting replay…' : 'Replay incident'} <RefreshCw size={14} /></button></div>
      {replay.data && <div className="info-banner" role="status">Replay request {replay.data.accepted ? 'accepted' : 'not accepted'} for incident {replay.data.incidentId}. No spacecraft command was issued.</div>}
      <div className="investigation-layout"><div className="investigation-main"><Panel><SectionHead title="Request an evidence review" meta="This creates a recorded investigation" /><form className="copilot-form" onSubmit={run}><label htmlFor="incident-question">What should the copilot investigate?</label><textarea id="incident-question" value={question} onChange={(e) => setQuestion(e.target.value)} placeholder={`What evidence explains “${incident.title}”?`} maxLength={2000} data-testid="input-incident-question" /><div className="form-actions"><span>Evidence sufficiency and missing evidence will be reported.</span><button className="button-primary" disabled={investigate.isPending} data-testid="button-run-investigation">{investigate.isPending ? 'Retrieving sources…' : 'Investigate incident'} <ArrowRight size={14} /></button></div>{investigate.isError && <p className="form-error" role="alert">{errText(investigate.error)}</p>}</form></Panel>
        <Panel><SectionHead title="Incident timeline" meta={`${q.data?.timeline?.length ?? 0} entries`} />{q.data?.timeline?.length ? <div className="timeline">{q.data.timeline.map((entry) => <div className="timeline-row" key={entry.id}><span className="timeline-node" /><div><span className="mono timeline-time">{when(entry.occurredAt)}</span><b>{titleCase(entry.kind)}</b><p>{entry.description}</p><span className="source-label">SOURCE {entry.sourceId}</span></div></div>)}</div> : <div className="empty-inline">No timeline entries returned for this incident.</div>}</Panel>
        {q.data?.telemetry?.length ? <Panel><SectionHead title="Associated telemetry" meta={`${q.data.telemetry.length} records`} /><div className="table-scroll"><table><thead><tr><th>Timestamp</th><th>Battery V</th><th>Solar W</th><th>Thermal °C</th><th>Anomaly</th><th>Source</th></tr></thead><tbody>{q.data.telemetry.map((t) => <tr key={t.id}><td className="mono">{when(t.timestamp)}</td><td className="mono">{t.batteryVoltage.toFixed(2)}</td><td className="mono">{t.solarPower.toFixed(1)}</td><td className="mono">{t.batteryTemperature.toFixed(1)}</td><td><Badge kind={t.anomalyStatus}>{titleCase(t.anomalyStatus)}</Badge></td><td>{t.sourceLabel}</td></tr>)}</tbody></table></div></Panel> : null}
      </div><div className="investigation-aside"><Panel><SectionHead title="Related historical incidents" meta="Backend similarity retrieval" /><LoadState loading={similar.isLoading} error={similar.error} empty={!similar.data?.length && !similar.isLoading && !similar.isError} retry={() => similar.refetch()} />{similar.data?.map((match) => <div className="similar-card" key={match.incident.id}><div><Badge kind={match.incident.severity}>{match.incident.severity}</Badge><span className="mono similarity">{(match.similarity * 100).toFixed(0)}% match</span></div><b>{match.incident.title}</b><p>{match.rationale.join(' · ')}</p></div>)}</Panel></div></div>
      {result && <Panel className="result-panel"><InvestigationResult data={result} /></Panel>}
    </>}
  </div>;
}

function Copilot() {
  const [question, setQuestion] = useState('');
  const [result, setResult] = useState<Investigation | null>(null);
  const mutation = useInvestigate();
  const ask = (e: FormEvent) => { e.preventDefault(); mutation.mutate({ data: { question: question.trim() } }, { onSuccess: (data) => { setResult(data); queryClient.invalidateQueries({ queryKey: getGetAuditQueryKey() }); } }); };
  return <div className="page-wrap enter">
    <PageHead eyebrow="MISSION INTELLIGENCE / RETRIEVAL-AUGMENTED" title="Evidence copilot" description="Ask a spacecraft-health question. Each response is grounded in retrieved records and written to the audit trail." right={<Badge kind="success">COMMANDS DISABLED</Badge>} />
    <div className="copilot-layout"><div className="copilot-main"><Panel className="copilot-query"><div className="copilot-emblem"><Sparkles size={19} /></div><div className="copilot-title"><div className="eyebrow">OPERATOR QUERY</div><h2>What do the records support?</h2><p>Questions are evaluated against available telemetry, incident context and evidence sources.</p></div><form className="copilot-form" onSubmit={ask}><label htmlFor="copilot-question">Investigation question</label><textarea id="copilot-question" value={question} onChange={(e) => setQuestion(e.target.value)} onKeyDown={(e) => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); if (question.trim()) mutation.mutate({ data: { question: question.trim() } }, { onSuccess: setResult }); } }} placeholder="What changed in the power subsystem before the latest anomaly?" maxLength={2000} required data-testid="input-copilot-question" /><div className="form-actions"><span>Enter to submit · Shift + Enter for a new line</span><button className="button-primary" disabled={!question.trim() || mutation.isPending} data-testid="button-ask-copilot">{mutation.isPending ? 'Searching evidence…' : 'Investigate'} <ArrowRight size={14} /></button></div>{mutation.isError && <p className="form-error" role="alert">{errText(mutation.error)}</p>}</form></Panel>
      {result ? <Panel className="result-panel"><InvestigationResult data={result} /></Panel> : <Panel className="copilot-guide"><div className="guide-step"><span>01</span><div><b>Retrieve</b><p>Search evidence sources and related mission context.</p></div></div><div className="guide-step"><span>02</span><div><b>Separate</b><p>Facts, hypotheses, recommendations and evidence gaps remain distinct.</p></div></div><div className="guide-step"><span>03</span><div><b>Record</b><p>The investigation and evidence references are written to the audit trail.</p></div></div></Panel>}
    </div><div className="copilot-aside"><Panel><div className="eyebrow">INTERPRETATION KEY</div><div className="legend-list"><div><span className="legend-tag facts">FACT</span><p>Directly supported by a retrieved source.</p></div><div><span className="legend-tag hypothesis">HYPOTHESIS</span><p>A possible explanation, not a confirmed cause.</p></div><div><span className="legend-tag recommendation">RECOMMENDATION</span><p>For operator evaluation; never an instruction.</p></div><div><span className="legend-tag insufficient">INSUFFICIENT</span><p>Evidence gaps are disclosed, not filled by guesswork.</p></div></div></Panel><Panel className="authority-panel"><ShieldCheck size={19} /><b>Human authority remains with the operator.</b><p>Mission Operations Copilot is decision support. It does not control a spacecraft or issue commands.</p><span className="mono">COMMAND ISSUED: NONE</span></Panel></div></div>
  </div>;
}

function Evidence() {
  const params = new URLSearchParams(window.location.search);
  const [query, setQuery] = useState('');
  const [selectedId, setSelectedId] = useState(params.get('source') || '');
  const search = useSearchEvidence();
  const detail = useGetEvidence(selectedId, { query: { enabled: !!selectedId, queryKey: getGetEvidenceQueryKey(selectedId) } });
  const submit = (e: FormEvent) => { e.preventDefault(); search.mutate({ data: { query: query.trim(), limit: 20 } }); };
  return <div className="page-wrap enter">
    <PageHead eyebrow="SOURCE TRACEABILITY / EXPLORER" title="Evidence library" description="Search indexed source records and inspect the source behind a claim." right={<Badge kind="neutral">BACKEND SOURCES</Badge>} />
    <Panel className="evidence-search-panel"><form className="search-form" onSubmit={submit}><Search size={18} /><input value={query} onChange={(e) => setQuery(e.target.value)} placeholder="Search procedures, event context, telemetry…" aria-label="Search evidence" data-testid="input-evidence-search" /><button className="button-primary" disabled={!query.trim() || search.isPending} data-testid="button-search-evidence">{search.isPending ? 'Searching…' : 'Search sources'} <ArrowRight size={14} /></button></form>{search.isError && <div className="form-error">{errText(search.error)}</div>}</Panel>
    <div className="evidence-layout"><Panel><SectionHead title="Retrieved source records" meta={search.data ? `${search.data.length} matches` : 'Submit a search to retrieve evidence'} /><LoadState loading={search.isPending} error={search.error} empty={!!search.data && !search.data.length && !search.isPending && !search.isError} />{search.data && <div className="evidence-results">{search.data.map((source) => <button className={`evidence-result ${selectedId === source.sourceId ? 'selected' : ''}`} key={source.sourceId} onClick={() => setSelectedId(source.sourceId)} data-testid={`button-source-${source.sourceId}`}><div className="source-result-top"><Badge kind="neutral">{titleCase(source.sourceType)}</Badge><span className="mono">{(source.score * 100).toFixed(0)}% relevance</span></div><b>{source.title}</b><p>{source.content}</p><div className="source-result-bottom"><span>{source.sourceId}</span><span>{source.occurredAt ? when(source.occurredAt) : 'No event time'}</span></div></button>)}</div>}
    </Panel><Panel className="evidence-detail"><SectionHead title="Source detail" meta={selectedId ? `ID ${selectedId}` : 'Select a source record'} />{selectedId ? <><LoadState loading={detail.isLoading} error={detail.error} empty={!detail.data && !detail.isLoading && !detail.isError} retry={() => detail.refetch()} />{detail.data && <div className="source-detail-copy"><Badge kind="neutral">{titleCase(detail.data.sourceType)}</Badge><h3>{detail.data.title}</h3><p>{detail.data.content}</p><div className="detail-meta"><span>SOURCE ID <b className="mono">{detail.data.sourceId}</b></span><span>OCCURRED <b className="mono">{detail.data.occurredAt ? when(detail.data.occurredAt) : '—'}</b></span><span>RELEVANCE <b>{detail.data.relevance}</b></span><span>SCORE <b className="mono">{(detail.data.score * 100).toFixed(1)}%</b></span></div></div>}</> : <div className="source-empty"><FileSearch size={22} /><b>Evidence stays attached to its origin.</b><p>Search the source library, or follow an evidence citation from an investigation.</p></div>}</Panel></div>
  </div>;
}

function Audit() {
  const q = useGetAudit();
  const records = q.data || [];
  return <div className="page-wrap enter"><PageHead eyebrow="OPERATOR TRACE / RECORD OF ACTION" title="Audit trail" description="Investigations recorded by the backend, with source references and evidence validation." right={<Badge kind="success"><Check size={12} /> NO COMMANDS ISSUED</Badge>} />
    <div className="source-banners"><div className="source-banner"><FileClock size={17} /><div><b>INVESTIGATIONS ARE RECORDED</b><small>Each completed question creates an audit record on the service</small></div></div><div className="source-banner no-connection"><ShieldCheck size={16} /><div><b>COMMAND ISSUED: NONE</b><small>Recommendations remain operator-reviewed decision support</small></div></div></div>
    <div className="audit-stats"><Metric label="Recorded investigations" value={records.length} testId="value-audit-count" /><Metric label="Source references" value={records.reduce((sum, row) => sum + row.retrievedSourceIds.length, 0)} testId="value-audit-sources" /><Metric label="Command authority" value="NONE" note="NO COMMANDS ISSUED" testId="value-audit-command" /></div>
    <Panel><SectionHead title="Investigation log" meta="Ordered as returned by the audit service" /><LoadState loading={q.isLoading} error={q.error} empty={!records.length && !q.isLoading && !q.isError} retry={() => q.refetch()} />{records.length > 0 && <div className="table-scroll"><table className="audit-table"><thead><tr><th>Recorded</th><th>Question</th><th>Outcome</th><th>Evidence</th><th>Confidence</th><th>Sources</th><th>Record</th></tr></thead><tbody>{records.map((record) => <tr key={record.id} data-testid={`row-audit-${record.id}`}><td className="mono">{when(record.timestamp)}</td><td className="audit-question">{record.question}</td><td><Badge kind={record.evidenceSufficiency}>{titleCase(record.evidenceSufficiency)}</Badge><div className="table-sub">{record.validation}</div></td><td>{record.recommendation}</td><td className="mono">{(record.confidence * 100).toFixed(1)}%</td><td>{record.retrievedSourceIds.length} <span className="muted">sources</span></td><td><span className="mono">{record.id}</span><div className="table-sub">command: {record.commandIssued}</div></td></tr>)}</tbody></table></div>}</Panel>
  </div>;
}

function Safety() {
  return <div className="page-wrap enter"><PageHead eyebrow="MISSION SAFETY / HUMAN AUTHORITY" title="Safety guardrails" description="Boundaries for an evidence-grounded decision-support interface." right={<Badge kind="success"><ShieldCheck size={12} /> OPERATOR CONTROL</Badge>} />
    <div className="safety-banner"><div className="safety-emblem"><ShieldCheck size={26} /></div><div><span>NON-NEGOTIABLE BOUNDARY</span><h2 className="display">No spacecraft control.<br /><em>No live connection.</em></h2><p>This interface presents simulated telemetry and public historical records for operator evaluation only.</p></div></div>
    <div className="safety-grid"><Panel className="guardrail-card"><div className="guardrail-index">01 / DATA ORIGIN</div><Radio size={18} /><h3>Provenance remains visible</h3><p>Telemetry source labels distinguish simulated live values, public historical data, and operator uploads. They are not represented as current vehicle state.</p><Badge kind="warning">SIMULATED LIVE TELEMETRY</Badge></Panel><Panel className="guardrail-card"><div className="guardrail-index">02 / REASONING</div><FileSearch size={18} /><h3>Evidence is inspectable</h3><p>Retrieved evidence is exposed alongside claims. Observations, correlated context, hypotheses, and recommendations are shown as different kinds of statements.</p><div className="guardrail-tags"><span>FACT</span><span>HYPOTHESIS</span><span>RECOMMENDATION</span></div></Panel><Panel className="guardrail-card"><div className="guardrail-index">03 / UNCERTAINTY</div><CircleHelp size={18} /><h3>Gaps are stated</h3><p>When evidence is partial or insufficient, missing evidence and confidence are surfaced instead of implying certainty.</p><Badge kind="insufficient">INSUFFICIENT EVIDENCE</Badge></Panel><Panel className="guardrail-card"><div className="guardrail-index">04 / AUTHORITY</div><Shield size={18} /><h3>The operator decides</h3><p>Recommendations are not commands. The interface has no spacecraft command capability; all actions are confined to analysis and backend-recorded requests.</p><Badge kind="success">COMMAND ISSUED: NONE</Badge></Panel></div>
    <div className="safety-bottom"><div><b>Data context</b><span>Operational presentation does not imply operational vehicle access.</span></div><div><b>Decision boundary</b><span>Every recommendation requires human evaluation and authorization outside this system.</span></div><div><b>Network state</b><span className="mono">NO LIVE SPACECRAFT CONNECTION</span></div></div>
  </div>;
}

function Architecture() {
  const health = useHealthCheck();
  return <div className="page-wrap enter"><PageHead eyebrow="SYSTEM MODEL / INFORMATION FLOW" title="Processing flow" description="How mission context moves through retrieval and into a traceable operator investigation." right={<Badge kind={health.isError ? 'critical' : 'success'}>{health.isLoading ? 'SERVICE CHECKING' : health.isError ? 'API UNAVAILABLE' : 'API AVAILABLE'}</Badge>} />
    <Panel className="flow-panel"><div className="flow-topline"><span>DECISION SUPPORT PATH</span><span className="mono">NO COMMAND PATH</span></div><div className="flow-track">
      {[{ n: '01', icon: Database, title: 'Mission records', text: 'Telemetry, mission events, incidents, and uploaded records enter through the service.' }, { n: '02', icon: Search, title: 'Evidence retrieval', text: 'The copilot retrieves relevant source records for a specific operator question.' }, { n: '03', icon: Layers3, title: 'Claim separation', text: 'Observed facts, historical context, hypotheses, recommendations, and missing evidence are kept distinct.' }, { n: '04', icon: FileClock, title: 'Audit record', text: 'The request, outcome, retrieved source IDs, confidence, and validation are recorded.' }].map((step, index) => <div className="flow-step" key={step.n}><div className="flow-step-head"><span>{step.n}</span><step.icon size={19} /></div><h3>{step.title}</h3><p>{step.text}</p>{index < 3 && <ArrowRight className="flow-arrow" size={16} />}</div>)}
    </div><div className="flow-boundary"><ShieldCheck size={16} /><b>HUMAN DECISION BOUNDARY</b><span>Analysis ends at an operator-reviewed recommendation. No command is generated or transmitted.</span><Badge kind="success">COMMAND ISSUED: NONE</Badge></div></Panel>
    <div className="architecture-lower"><Panel><SectionHead title="Input provenance" meta="The origin travels with each record" /><div className="provenance-rows"><div><span className="origin-marker simulated" /><div><b>Simulated live telemetry</b><p>Generated stream for evaluation; not a real spacecraft connection.</p></div></div><div><span className="origin-marker historical" /><div><b>Public historical data</b><p>Historical values and events are labeled at their source.</p></div></div><div><span className="origin-marker upload" /><div><b>Operator upload</b><p>Validated CSV/JSON telemetry entered by the operator.</p></div></div></div></Panel><Panel><SectionHead title="Service health" meta="Reported by health endpoint" /><LoadState loading={health.isLoading} error={health.error} empty={!health.data && !health.isLoading && !health.isError} retry={() => health.refetch()} />{health.data && <div className="service-health"><span className="health-dot" /><span>HEALTH CHECK</span><b className="mono">{health.data.status}</b></div>}<div className="service-boundary"><Signal size={15} /><span>Spacecraft link</span><b>NOT CONNECTED</b></div></Panel></div>
  </div>;
}

function Ingestion() {
  const spacecraft = useGetSpacecraft();
  const mutation = useIngestTelemetry();
  const eventMutation = useIngestEvent();
  const qc = useQueryClient();
  const [sourceLabel, setSourceLabel] = useState<'OPERATOR UPLOAD' | 'PUBLIC HISTORICAL'>('OPERATOR UPLOAD');
  const [preview, setPreview] = useState<TelemetryInputItem[]>([]);
  const [filename, setFilename] = useState('');
  const [parseError, setParseError] = useState('');
  const [successText, setSuccessText] = useState('');
  const [eventMessage, setEventMessage] = useState('');
  const defaultCraft = spacecraft.data?.[0]?.id || '';
  const parseNumber = (value: unknown) => Number(value);
  const parseFile = async (file?: File) => {
    setParseError(''); setSuccessText(''); setPreview([]);
    if (!file) return;
    setFilename(file.name);
    try {
      const text = await file.text();
      let raw: unknown[];
      if (file.name.toLowerCase().endsWith('.json')) {
        const json = JSON.parse(text) as unknown;
        raw = Array.isArray(json) ? json : json && typeof json === 'object' && 'records' in json ? ((json as { records: unknown[] }).records) : [json];
      } else {
        const lines = text.split(/\r?\n/).filter((line) => line.trim());
        if (lines.length < 2) throw new Error('CSV file needs a header row and at least one sample.');
        const headers = lines[0].split(',').map((x) => x.trim());
        raw = lines.slice(1).map((line) => Object.fromEntries(line.split(',').map((value, i) => [headers[i], value.trim()])));
      }
      if (raw.length > 2000) throw new Error('Maximum upload size is 2,000 telemetry records.');
      if (!spacecraft.data?.length) throw new Error('Spacecraft registry is not available yet.');
      const normalized = raw.map((row) => {
        if (!row || typeof row !== 'object') throw new Error('Each telemetry record must be an object.');
        const obj = row as Record<string, unknown>;
        const item: TelemetryInputItem = {
          spacecraftId: String(obj.spacecraftId || defaultCraft),
          timestamp: String(obj.timestamp || ''),
          batteryVoltage: parseNumber(obj.batteryVoltage),
          solarPower: parseNumber(obj.solarPower),
          batteryTemperature: parseNumber(obj.batteryTemperature),
          communicationSignal: parseNumber(obj.communicationSignal),
          attitudeError: parseNumber(obj.attitudeError),
          cpuUsage: parseNumber(obj.cpuUsage),
          memoryUsage: parseNumber(obj.memoryUsage),
          reactionWheelSpeed: parseNumber(obj.reactionWheelSpeed),
        };
        if (!item.timestamp || !Number.isFinite(Date.parse(item.timestamp))) throw new Error('Each sample needs a valid timestamp.');
        if (Object.values(item).some((value) => typeof value === 'number' && !Number.isFinite(value))) throw new Error('Every telemetry field must contain a valid number.');
        if (!spacecraft.data?.some((craft) => craft.id === item.spacecraftId)) throw new Error(`Unknown spacecraft ID: ${item.spacecraftId}`);
        return item;
      });
      setPreview(normalized);
    } catch (error) { setParseError(errText(error)); }
  };
  const submit = () => mutation.mutate({ data: { sourceLabel, records: preview } }, { onSuccess: (result) => {
    setSuccessText(`${result.message} · ${result.count} record${result.count === 1 ? '' : 's'} accepted.`);
    setPreview([]);
    qc.invalidateQueries({ queryKey: getGetTelemetryHistoryQueryKey({ limit: 250 }) });
    qc.invalidateQueries({ queryKey: getGetLatestTelemetryQueryKey() });
    qc.invalidateQueries({ queryKey: getGetDashboardQueryKey() });
  } });
  const submitEvent = (e: FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const form = new FormData(e.currentTarget);
    const payload: EventInput = {
      id: `upload-${Date.now()}`,
      eventType: String(form.get('eventType')).trim(),
      subsystem: String(form.get('subsystem')).trim(),
      description: String(form.get('description')).trim(),
      occurredAt: new Date(String(form.get('occurredAt'))).toISOString(),
      severity: String(form.get('severity')) as EventInput['severity'],
      sourceLabel: sourceLabel,
    };
    eventMutation.mutate({ data: payload }, { onSuccess: () => {
      setEventMessage('Mission event accepted by the backend.');
      qc.invalidateQueries({ queryKey: getGetEventsQueryKey() });
      qc.invalidateQueries({ queryKey: getGetDashboardQueryKey() });
    }, onError: (error) => setEventMessage(errText(error)) });
  };
  return <div className="page-wrap enter"><PageHead eyebrow="MISSION DATA / OPERATOR INGESTION" title="Telemetry ingestion" description="Validate and submit CSV or JSON telemetry records to the backend." right={<Badge kind="warning">OPERATOR UPLOAD</Badge>} />
    <div className="source-banners"><div className="source-banner historical"><Globe2 size={16} /><div><b>PUBLIC HISTORICAL</b><small>Label only if these records are public historical data</small></div></div><div className="source-banner no-connection"><Signal size={16} /><div><b>NO LIVE SPACECRAFT CONNECTION</b><small>Uploads do not connect to or control a vehicle</small></div></div></div>
    <LoadState loading={spacecraft.isLoading} error={spacecraft.error} empty={!spacecraft.data?.length && !spacecraft.isLoading && !spacecraft.isError} retry={() => spacecraft.refetch()} />
    <div className="ingestion-layout"><Panel className="upload-panel"><div className="upload-heading"><div className="upload-icon"><Upload size={19} /></div><div><h2>Choose a telemetry file</h2><p>CSV or JSON · Up to 2,000 records per upload</p></div></div>
      <label className="file-drop"><input type="file" accept=".csv,.json,application/json,text/csv" onChange={(e) => void parseFile(e.target.files?.[0])} data-testid="input-telemetry-file" /><Upload size={21} /><b>{filename || 'Select or drop a file'}</b><span>CSV with column headers or JSON array / records object</span></label>
      <div className="field-row"><label htmlFor="ingest-source">Record source</label><select id="ingest-source" value={sourceLabel} onChange={(e) => setSourceLabel(e.target.value as typeof sourceLabel)} data-testid="select-ingest-source"><option value="OPERATOR UPLOAD">Operator upload</option><option value="PUBLIC HISTORICAL">Public historical data</option></select></div>
      {spacecraft.data && <div className="field-row"><span>Default spacecraft for records without spacecraftId</span><b className="mono">{defaultCraft}</b></div>}
      {parseError && <div className="form-error" role="alert"><AlertTriangle size={14} />{parseError}</div>}
      {successText && <div className="success-message" role="status"><Check size={14} />{successText}</div>}
      {mutation.isError && <div className="form-error" role="alert">{errText(mutation.error)}</div>}
      <div className="upload-footer"><span>{preview.length ? `${preview.length} records validated locally` : 'Upload is sent to the backend only after validation.'}</span><button className="button-primary" onClick={submit} disabled={!preview.length || mutation.isPending} data-testid="button-submit-ingestion">{mutation.isPending ? 'Submitting…' : `Submit ${preview.length || ''} record${preview.length === 1 ? '' : 's'}`} <ArrowRight size={14} /></button></div>
    </Panel><Panel className="schema-panel"><div className="eyebrow">EXPECTED SAMPLE FIELDS</div><p className="schema-intro">Fields below are passed to the telemetry ingest API. Numeric fields are validated before submission.</p><div className="schema-list">{['spacecraftId · string', 'timestamp · ISO 8601', 'batteryVoltage · number', 'solarPower · number', 'batteryTemperature · number', 'communicationSignal · number', 'attitudeError · number', 'cpuUsage · number', 'memoryUsage · number', 'reactionWheelSpeed · number'].map((field) => <div key={field}><span className="schema-check"><Check size={11} /></span><code>{field}</code></div>)}</div><div className="schema-note"><ShieldCheck size={15} /><span>Backend validation is authoritative. Upload results are confirmed by the service.</span></div></Panel></div>
    {preview.length > 0 && <Panel className="preview-panel"><SectionHead title="Upload preview" meta="First 8 parsed records" /><div className="table-scroll"><table><thead><tr><th>Timestamp</th><th>Spacecraft</th><th>Battery V</th><th>Solar W</th><th>Temperature °C</th><th>Comm dBm</th><th>Attitude °</th><th>CPU %</th></tr></thead><tbody>{preview.slice(0, 8).map((row, i) => <tr key={`${row.timestamp}-${i}`}><td className="mono">{when(row.timestamp)}</td><td className="mono">{row.spacecraftId}</td><td className="mono">{row.batteryVoltage}</td><td className="mono">{row.solarPower}</td><td className="mono">{row.batteryTemperature}</td><td className="mono">{row.communicationSignal}</td><td className="mono">{row.attitudeError}</td><td className="mono">{row.cpuUsage}</td></tr>)}</tbody></table></div></Panel>}
    <Panel className="event-upload-panel"><SectionHead title="Ingest a mission event" meta="Optional event record · submitted directly to the backend" /><form className="event-upload-form" onSubmit={submitEvent}><label>Event type<input name="eventType" required placeholder="e.g. operator observation" data-testid="input-event-type" /></label><label>Subsystem<input name="subsystem" required placeholder="e.g. power" data-testid="input-event-subsystem" /></label><label>Severity<select name="severity" defaultValue="INFO" data-testid="select-event-severity"><option>INFO</option><option>WARNING</option><option>HIGH</option><option>CRITICAL</option></select></label><label>Occurred at<input name="occurredAt" type="datetime-local" required data-testid="input-event-time" /></label><label className="wide-field">Description<textarea name="description" required data-testid="input-event-description" /></label><div className="event-submit-row">{eventMessage && <span className="form-note">{eventMessage}</span>}<button className="button-primary" disabled={eventMutation.isPending} data-testid="button-submit-event">{eventMutation.isPending ? 'Submitting…' : 'Submit mission event'} <ArrowRight size={14} /></button></div></form></Panel>
  </div>;
}

function RoutedErrorBoundary({ children }: { children: ReactNode }) {
  const [location] = useLocation();
  return <ErrorBoundary resetKey={location}>{children}</ErrorBoundary>;
}
function NotFound() { return <div className="page-wrap"><div className="empty-page"><div className="eyebrow">404 / ROUTE NOT FOUND</div><h1 className="display">Mission page unavailable.</h1><Link href="/" className="button-primary">Return to overview <ArrowRight size={14} /></Link></div></div>; }

function Router() {
  return <RoutedErrorBoundary><Shell><Switch>
    <Route path="/" component={Home} />
    <Route path="/dashboard" component={Dashboard} />
    <Route path="/telemetry" component={Telemetry} />
    <Route path="/incidents" component={Incidents} />
    <Route path="/incidents/:incidentId" component={IncidentInvestigation} />
    <Route path="/copilot" component={Copilot} />
    <Route path="/evidence" component={Evidence} />
    <Route path="/audit" component={Audit} />
    <Route path="/safety" component={Safety} />
    <Route path="/architecture" component={Architecture} />
    <Route path="/ingestion" component={Ingestion} />
    <Route component={NotFound} />
  </Switch></Shell></RoutedErrorBoundary>;
}

function App() {
  return <QueryClientProvider client={queryClient}><TooltipProvider><WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, '')}><Router /></WouterRouter><Toaster /></TooltipProvider></QueryClientProvider>;
}
export default App;
