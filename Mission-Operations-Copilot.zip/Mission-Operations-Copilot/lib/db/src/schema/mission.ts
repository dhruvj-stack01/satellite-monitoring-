import {
  index,
  integer,
  jsonb,
  pgTable,
  real,
  text,
  timestamp,
} from "drizzle-orm/pg-core";

export const spacecraftTable = pgTable("spacecraft", {
  id: text("id").primaryKey(),
  name: text("name").notNull(),
  status: text("status").notNull().default("NOMINAL"),
  sourceLabel: text("source_label").notNull(),
  lastContactAt: timestamp("last_contact_at", { withTimezone: true })
    .notNull()
    .defaultNow(),
});

export const telemetryTable = pgTable(
  "telemetry",
  {
    id: text("id").primaryKey(),
    spacecraftId: text("spacecraft_id")
      .notNull()
      .references(() => spacecraftTable.id),
    timestamp: timestamp("timestamp", { withTimezone: true }).notNull(),
    batteryVoltage: real("battery_voltage").notNull(),
    solarPower: real("solar_power").notNull(),
    batteryTemperature: real("battery_temperature").notNull(),
    communicationSignal: real("communication_signal").notNull(),
    attitudeError: real("attitude_error").notNull(),
    cpuUsage: real("cpu_usage").notNull(),
    memoryUsage: real("memory_usage").notNull(),
    reactionWheelSpeed: real("reaction_wheel_speed").notNull(),
    anomalyScore: real("anomaly_score").notNull().default(0),
    anomalyStatus: text("anomaly_status").notNull().default("NOMINAL"),
    sourceLabel: text("source_label").notNull(),
  },
  (table) => [index("telemetry_spacecraft_time_idx").on(table.spacecraftId, table.timestamp)],
);

export const missionEventsTable = pgTable(
  "events",
  {
    id: text("id").primaryKey(),
    eventType: text("event_type").notNull(),
    subsystem: text("subsystem").notNull(),
    description: text("description").notNull(),
    occurredAt: timestamp("occurred_at", { withTimezone: true }).notNull(),
    severity: text("severity").notNull(),
    sourceLabel: text("source_label").notNull(),
  },
  (table) => [index("events_occurred_at_idx").on(table.occurredAt)],
);

export const incidentsTable = pgTable(
  "incidents",
  {
    id: text("id").primaryKey(),
    title: text("title").notNull(),
    severity: text("severity").notNull(),
    status: text("status").notNull(),
    summary: text("summary").notNull(),
    openedAt: timestamp("opened_at", { withTimezone: true }).notNull(),
    updatedAt: timestamp("updated_at", { withTimezone: true }).notNull(),
  },
  (table) => [index("incidents_status_updated_idx").on(table.status, table.updatedAt)],
);

export const documentsTable = pgTable("documents", {
  id: text("id").primaryKey(),
  title: text("title").notNull(),
  sourceType: text("source_type").notNull(),
  content: text("content").notNull(),
  occurredAt: timestamp("occurred_at", { withTimezone: true }),
  sourceLabel: text("source_label").notNull(),
});

export const documentChunksTable = pgTable(
  "document_chunks",
  {
    id: text("id").primaryKey(),
    documentId: text("document_id")
      .notNull()
      .references(() => documentsTable.id, { onDelete: "cascade" }),
    chunkIndex: integer("chunk_index").notNull(),
    content: text("content").notNull(),
    embedding: jsonb("embedding").$type<number[]>().notNull(),
  },
  (table) => [index("document_chunks_document_idx").on(table.documentId)],
);

export const auditLogsTable = pgTable(
  "audit_logs",
  {
    id: text("id").primaryKey(),
    timestamp: timestamp("timestamp", { withTimezone: true }).notNull(),
    question: text("question").notNull(),
    incidentId: text("incident_id"),
    retrievedSourceIds: text("retrieved_source_ids").array().notNull(),
    answerSummary: text("answer_summary").notNull(),
    recommendation: text("recommendation").notNull(),
    confidence: real("confidence").notNull(),
    validation: text("validation").notNull(),
    evidenceSufficiency: text("evidence_sufficiency").notNull(),
    commandIssued: text("command_issued").notNull().default("NONE"),
  },
  (table) => [index("audit_logs_timestamp_idx").on(table.timestamp)],
);

export const similarIncidentsTable = pgTable("similar_incidents", {
  id: text("id").primaryKey(),
  incidentId: text("incident_id").notNull(),
  relatedIncidentId: text("related_incident_id").notNull(),
  similarity: real("similarity").notNull(),
  rationale: text("rationale").array().notNull(),
});

export const contactMessagesTable = pgTable("contact_messages", {
  id: text("id").primaryKey(),
  name: text("name").notNull(),
  email: text("email").notNull(),
  organization: text("organization").notNull().default(""),
  message: text("message").notNull(),
  createdAt: timestamp("created_at", { withTimezone: true })
    .notNull()
    .defaultNow(),
});
